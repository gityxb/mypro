package com.yxb.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.yxb.dao.*;
import com.yxb.entity.PageResult;
import com.yxb.entity.Result;
import com.yxb.pojo.Activity;
import com.yxb.pojo.PublicActUser;
import com.yxb.pojo.Role;
import com.yxb.service.ActivityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import java.util.List;
import java.util.Map;

@Service
public class ActivityServiceImpl implements ActivityService {

    @Autowired
    private ActivityUserMapper activityUserMapper;

    @Autowired
    private ActivityMapper activityMapper;

    @Autowired
    private MessageMapper messageMapper;

    @Autowired
    private CommentMapper commentMapper;

    @Autowired
    private RoleMapper roleMapper;

    /**
     * 返回全部记录
     * @return
     */
    public List<Activity> findAll() {
        return activityMapper.selectAll();
    }

    /**
     * 分页查询
     * @param page 页码
     * @param size 每页记录数
     * @return 分页结果
     */
    public PageResult<Activity> findPage(int page, int size) {
        PageHelper.startPage(page,size);
        Page<Activity> activitys = (Page<Activity>) activityMapper.selectAll();
        return new PageResult<Activity>(activitys.getTotal(),activitys.getResult());
    }

    /**
     * 条件查询
     * @param searchMap 查询条件
     * @return
     */
    public List<Activity> findList(Map<String, Object> searchMap) {
        Example example = createExample(searchMap);
        return activityMapper.selectByExample(example);
    }

    /**
     * 分页+条件查询
     * @param searchMap
     * @param page
     * @param size
     * @return
     */
    public PageResult<Activity> findPage(Map<String, Object> searchMap, int page, int size) {
        PageHelper.startPage(page,size);
        Example example = createExample(searchMap);
        Page<Activity> activitys = (Page<Activity>) activityMapper.selectByExample(example);
        return new PageResult<Activity>(activitys.getTotal(),activitys.getResult());
    }

    /**
     * 根据Id查询
     * @param id
     * @return
     */
    public Activity findById(Integer id) {
        return activityMapper.selectByPrimaryKey(id);
    }

    /**
     * 新增
     * @param activity
     */
    public void add(Activity activity) {

        activityMapper.insertSelective(activity);
    }

    /**
     * 修改
     * @param activity
     */
    public void update(Activity activity) {
        activityMapper.updateByPrimaryKeySelective(activity);
    }

    /**
     *  删除
     * @param id
     */
    public void delete(Integer id) {
        activityMapper.deleteByPrimaryKey(id);
    }

    @Override
    public int updateSetStus(Activity activity) {
        return activityMapper.updateSetStus(activity);
    }

    @Override
    public PublicActUser selectByPicActUser(Integer id) {
        return activityMapper.selectByPicActUser(id);
    }

    @Override
    public List<Activity> selActivity(String username) {
        return activityMapper.selActivity(username);
    }

    @Override
    public List<Activity> selPicAct(String username) {
        return activityMapper.selPicAct(username);
    }

    @Override
    public Integer[] selActId(String username) {
        return activityMapper.selActId(username);
    }

    @Override
    public List<Activity> selByTime() {
        return activityMapper.selByTime();
    }

    @Override
    public List<Activity> selByOrderCount() {
        return activityMapper.selByOrderCount();
    }

    @Transactional(propagation = Propagation.REQUIRED,rollbackFor = {Exception.class})
    public void deleteAct(Integer id) {
            activityMapper.deleteByPrimaryKey(id);
            activityUserMapper.deleteByActivityId(id);
            commentMapper.deleteCommentByActId(id);

    }

    /**
     * 构建查询条件
     * @param searchMap
     * @return
     */
    private Example createExample(Map<String, Object> searchMap){
        Example example=new Example(Activity.class);
        Example.Criteria criteria = example.createCriteria();
        if(searchMap!=null){
            // 活动简介
            if(searchMap.get("description")!=null && !"".equals(searchMap.get("description"))){
                criteria.andLike("description","%"+searchMap.get("description")+"%");
            }
            // 活动名称
            if(searchMap.get("name")!=null && !"".equals(searchMap.get("name"))){
                criteria.andLike("name","%"+searchMap.get("name")+"%");
            }
            // 活动地点
            if(searchMap.get("address")!=null && !"".equals(searchMap.get("address"))){
                criteria.andLike("address","%"+searchMap.get("address")+"%");
            }
            // 审核状态(1审核通过，0没通过)
            if(searchMap.get("status")!=null && !"".equals(searchMap.get("status"))){
                criteria.andLike("status","%"+searchMap.get("status")+"%");
            }

            // 活动id
            if(searchMap.get("id")!=null ){
                criteria.andEqualTo("id",searchMap.get("id"));
            }
            // 活动类型
            if(searchMap.get("categoryId")!=null ){
                criteria.andEqualTo("categoryId",searchMap.get("categoryId"));
            }
            // 当前人数
            if(searchMap.get("count")!=null ){
                criteria.andEqualTo("count",searchMap.get("count"));
            }
            // 最多人数限制
            if(searchMap.get("maxCount")!=null ){
                criteria.andEqualTo("maxCount",searchMap.get("maxCount"));
            }
            // 最少拼团人数
            if(searchMap.get("minCount")!=null ){
                criteria.andEqualTo("minCount",searchMap.get("minCount"));
            }
            // 联系方式
            if(searchMap.get("userId")!=null ){
                criteria.andEqualTo("userId",searchMap.get("userId"));
            }
            // 押金
            if(searchMap.get("cash")!=null ){
                criteria.andEqualTo("cash",searchMap.get("cash"));
            }

        }
        return example;
    }

}
