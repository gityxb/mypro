package com.yxb.service;
import com.yxb.entity.PageResult;
import com.yxb.pojo.Message;

import java.util.*;

/**
 * message业务逻辑层
 */
public interface MessageService {

    public List<Message> findAll();

    public PageResult<Message> findPage(int page, int size);

    public List<Message> findList(Map<String, Object> searchMap);

    public PageResult<Message> findPage(Map<String, Object> searchMap, int page, int size);

    public Message findById(Integer id);

    public void add(Message message);

    public void update(Message message);

    public void delete(Integer id);

    public List<Message> findUnRead();

    public List<Message> findRead();

    public int setStuts(Integer id);

}
