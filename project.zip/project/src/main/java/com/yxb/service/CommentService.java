package com.yxb.service;
import com.yxb.entity.PageResult;
import com.yxb.pojo.Comment;

import java.util.*;

/**
 * comment业务逻辑层
 */
public interface CommentService {


    public List<Comment> findAll();


    public PageResult<Comment> findPage(int page, int size);


    public List<Comment> findList(Map<String, Object> searchMap);


    public PageResult<Comment> findPage(Map<String, Object> searchMap, int page, int size);


    public Comment findById(Integer id);

    public void add(Comment comment);


    public void update(Comment comment);


    public void delete(Integer id);

    public List<Comment> selCommentList(Integer actId);

    public List<Comment> selChildCommentList(Integer pid);

    public Integer selCommentCount(Integer actId);

    public int  deleteCommentByActId(Integer actId);

}
