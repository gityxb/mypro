package com.yxb.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.yxb.dao.ActivityUserMapper;
import com.yxb.dao.UserMapper;
import com.yxb.entity.IdentityResult;
import com.yxb.entity.PageResult;
import com.yxb.pojo.User;
import com.yxb.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;
import java.util.List;
import java.util.Map;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private ActivityUserMapper activityUserMapper;

    /**
     * 返回全部记录
     * @return
     */
    public List<User> findAll() {
        return userMapper.selectAll();
    }

    /**
     * 分页查询
     * @param page 页码
     * @param size 每页记录数
     * @return 分页结果
     */
    public PageResult<User> findPage(int page, int size) {

        PageHelper.startPage(page,size);
        Page<User> users = (Page<User>) userMapper.selectAll();
        return new PageResult<User>(users.getTotal(),users.getResult());
    }

    /**
     * 条件查询
     * @param searchMap 查询条件
     * @return
     */
    public List<User> findList(Map<String, Object> searchMap) {
        Example example = createExample(searchMap);
        return userMapper.selectByExample(example);
    }

    @Override
    public int batchDelete(List<String> list) {
        return userMapper.batchDelete(list);
    }

    /**
     * 分页+条件查询
     * @param searchMap
     * @param page
     * @param size
     * @return
     */
    public PageResult<User> findPage(Map<String, Object> searchMap, int page, int size) {

        PageHelper.startPage(page,size);
        Example example = createExample(searchMap);
        Page<User> users = (Page<User>) userMapper.selectByExample(example);
        return new PageResult<User>(users.getTotal(),users.getResult());
    }

    /**
     * 根据Id查询
     * @param user_id
     * @return
     */
    public User findById(Integer userId) {
        return userMapper.selectByPrimaryKey(userId);
    }

    /**
     * 新增
     * @param user
     */
    public void add(User user) {
        userMapper.insertSelective(user);
    }

    /**
     * 修改
     * @param user
     */
    public void update(User user) {
        userMapper.updateByPrimaryKeySelective(user);
    }

    /**
     *  删除
     * @param user_id
     */
    @Transactional
    public void delete(Integer userId,String username) {

        userMapper.deleteByPrimaryKey(userId);
        activityUserMapper.deleteByUsername(username);

    }

    @Override
    public int verifyIdentity(String username, String password) {


        int i = userMapper.verifyIdentity(username,password);
        return i;
    }

    @Override
    public IdentityResult getRole(String username) {
        return userMapper.getRole(username);
    }

    @Override
    public User selUserByName(String username) {
        return userMapper.selUserByName(username);
    }

    @Override
    public User selPassByName(String username) {
        return userMapper.selPassByName(username);
    }

    @Override
    public int verifyName(String username) {
        return userMapper.verifyName(username);
    }

    /**
     * 构建查询条件
     * @param searchMap
     * @return
     */
    private Example createExample(Map<String, Object> searchMap){
        Example example=new Example(User.class);
        Example.Criteria criteria = example.createCriteria();
        if(searchMap!=null){
            // 用户名
            if(searchMap.get("username")!=null && !"".equals(searchMap.get("username"))){
                criteria.andLike("username","%"+searchMap.get("username")+"%");
            }
            // 手机号码
            if(searchMap.get("phone")!=null && !"".equals(searchMap.get("phone"))){
                criteria.andLike("phone","%"+searchMap.get("phone")+"%");
            }
            // 昵称
            if(searchMap.get("nickName")!=null && !"".equals(searchMap.get("nickName"))){
                criteria.andLike("nickName","%"+searchMap.get("nickName")+"%");
            }


        }
        return example;
    }

}
