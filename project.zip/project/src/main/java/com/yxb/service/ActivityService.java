package com.yxb.service;
import com.yxb.entity.PageResult;
import com.yxb.pojo.Activity;
import com.yxb.pojo.PublicActUser;

import java.util.*;

/**
 * activity业务逻辑层
 */
public interface ActivityService {


    public List<Activity> findAll();


    public PageResult<Activity> findPage(int page, int size);


    public List<Activity> findList(Map<String, Object> searchMap);


    public PageResult<Activity> findPage(Map<String, Object> searchMap, int page, int size);


    public Activity findById(Integer id);

    public void add(Activity activity);


    public void update(Activity activity);


    public void delete(Integer id);

    public int updateSetStus(Activity activity);

    public PublicActUser selectByPicActUser(Integer id);

    public List<Activity> selActivity(String username);

    public List<Activity> selPicAct(String username);

    public Integer[] selActId(String username);

    public List<Activity> selByTime();

    public List<Activity> selByOrderCount();

    public void deleteAct(Integer id) ;
}
