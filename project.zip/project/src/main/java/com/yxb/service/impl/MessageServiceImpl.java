package com.yxb.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.yxb.dao.MessageMapper;
import com.yxb.entity.PageResult;
import com.yxb.pojo.Message;
import com.yxb.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

import java.util.List;
import java.util.Map;

@Service
public class MessageServiceImpl implements MessageService {

    @Autowired
    private MessageMapper messageMapper;

    /**
     * 返回全部记录
     * @return
     */
    public List<Message> findAll() {
        return messageMapper.selectAll();
    }

    /**
     * 分页查询
     * @param page 页码
     * @param size 每页记录数
     * @return 分页结果
     */
    public PageResult<Message> findPage(int page, int size) {
        PageHelper.startPage(page,size);
        Page<Message> messages = (Page<Message>) messageMapper.selectAll();

        return new PageResult<Message>(messages.getTotal(),messages.getResult());
    }

    /**
     * 条件查询
     * @param searchMap 查询条件
     * @return
     */
    public List<Message> findList(Map<String, Object> searchMap) {
        Example example = createExample(searchMap);
        return messageMapper.selectByExample(example);
    }

    /**
     * 分页+条件查询
     * @param searchMap
     * @param page
     * @param size
     * @return
     */
    public PageResult<Message> findPage(Map<String, Object> searchMap, int page, int size) {
        PageHelper.startPage(page,size);
        Example example = createExample(searchMap);
        Page<Message> messages = (Page<Message>) messageMapper.selectByExample(example);
        return new PageResult<Message>(messages.getTotal(),messages.getResult());
    }

    /**
     * 根据Id查询
     * @param id
     * @return
     */
    public Message findById(Integer id) {
        return messageMapper.selectByPrimaryKey(id);
    }

    /**
     * 新增
     * @param message
     */
    public void add(Message message) {
        messageMapper.insertSelective(message);
    }

    /**
     * 修改
     * @param message
     */
    public void update(Message message) {
        messageMapper.updateByPrimaryKeySelective(message);
    }

    /**
     *  删除
     * @param id
     */
    public void delete(Integer id) {
        messageMapper.deleteByPrimaryKey(id);
    }

    @Override
    public List<Message> findUnRead() {
        return messageMapper.findUnRead();
    }

    @Override
    public List<Message> findRead() {
        return messageMapper.findRead();
    }

    @Override
    public int setStuts(Integer id) {
        return messageMapper.setStuts(id);
    }


    /**
     * 构建查询条件
     * @param searchMap
     * @return
     */
    private Example createExample(Map<String, Object> searchMap){
        Example example=new Example(Message.class);
        Example.Criteria criteria = example.createCriteria();
        if(searchMap!=null){
            // message
            if(searchMap.get("message")!=null && !"".equals(searchMap.get("message"))){
                criteria.andLike("message","%"+searchMap.get("message")+"%");
            }

            // id
            if(searchMap.get("id")!=null ){
                criteria.andEqualTo("id",searchMap.get("id"));
            }
            // user_id
            if(searchMap.get("userId")!=null ){
                criteria.andEqualTo("userId",searchMap.get("userId"));
            }

        }
        return example;
    }

}
