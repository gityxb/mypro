package com.yxb.service;
import com.yxb.entity.IdentityResult;
import com.yxb.entity.PageResult;
import com.yxb.pojo.User;
import org.apache.ibatis.annotations.Param;

import java.util.*;

/**
 * user业务逻辑层
 */
public interface UserService {


    public List<User> findAll();


    public PageResult<User> findPage(int page, int size);


    public List<User> findList(Map<String, Object> searchMap);

    public int batchDelete(List<String> list);


    public PageResult<User> findPage(Map<String, Object> searchMap, int page, int size);


    public User findById(Integer user_id);

    public void add(User user);


    public void update(User user);


    public void delete(Integer userId,String username);

    public int verifyIdentity(String username,String password);

    public IdentityResult getRole(String username);

    public User selUserByName(String username);

    public User selPassByName(String username);

    public int verifyName(String username);




}
