package com.yxb.service;
import com.yxb.entity.PageResult;
import com.yxb.pojo.Activity;
import com.yxb.pojo.ActivityUser;
import com.yxb.pojo.User;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.*;

/**
 * activityUser业务逻辑层
 */
public interface ActivityUserService {


    public List<ActivityUser> findAll();


    public PageResult<ActivityUser> findPage(int page, int size);


    public List<ActivityUser> findList(Map<String, Object> searchMap);


    public PageResult<ActivityUser> findPage(Map<String, Object> searchMap, int page, int size);


    public ActivityUser findById(Integer id);

    public void add(ActivityUser activityUser);


    public void update(ActivityUser activityUser);


    public void delete(Integer id);

    public int selectUser(ActivityUser activityUser);

    public String[] selactUsers(Integer actId);


    public ArrayList<ArrayList<User>> getInActUser(String username);

    public int deleteTakeAct(Map<String, Object> mapOject);

    public int deleteByActivityId(Integer id);

    public int deleteByUsername(String username);

    public Integer[] selActByUserName(String username);
}
