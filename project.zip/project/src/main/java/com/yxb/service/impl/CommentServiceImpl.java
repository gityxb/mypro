package com.yxb.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.yxb.dao.CommentMapper;
import com.yxb.entity.PageResult;
import com.yxb.pojo.Comment;
import com.yxb.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

import java.util.List;
import java.util.Map;

@Service
public class CommentServiceImpl implements CommentService {

    @Autowired
    private CommentMapper commentMapper;

    /**
     * 返回全部记录
     * @return
     */
    public List<Comment> findAll() {
        return commentMapper.selectAll();
    }

    /**
     * 分页查询
     * @param page 页码
     * @param size 每页记录数
     * @return 分页结果
     */
    public PageResult<Comment> findPage(int page, int size) {
        PageHelper.startPage(page,size);
        Page<Comment> comments = (Page<Comment>) commentMapper.selectAll();
        return new PageResult<Comment>(comments.getTotal(),comments.getResult());
    }

    /**
     * 条件查询
     * @param searchMap 查询条件
     * @return
     */
    public List<Comment> findList(Map<String, Object> searchMap) {
        Example example = createExample(searchMap);
        return commentMapper.selectByExample(example);
    }

    /**
     * 分页+条件查询
     * @param searchMap
     * @param page
     * @param size
     * @return
     */
    public PageResult<Comment> findPage(Map<String, Object> searchMap, int page, int size) {
        PageHelper.startPage(page,size);
        Example example = createExample(searchMap);
        Page<Comment> comments = (Page<Comment>) commentMapper.selectByExample(example);
        return new PageResult<Comment>(comments.getTotal(),comments.getResult());
    }

    /**
     * 根据Id查询
     * @param id
     * @return
     */
    public Comment findById(Integer id) {
        return commentMapper.selectByPrimaryKey(id);
    }

    /**
     * 新增
     * @param comment
     */
    public void add(Comment comment) {
        commentMapper.insertSelective(comment);
    }

    /**
     * 修改
     * @param comment
     */
    public void update(Comment comment) {
        commentMapper.updateByPrimaryKeySelective(comment);
    }

    /**
     *  删除
     * @param id
     */
    public void delete(Integer id) {
        commentMapper.deleteByPrimaryKey(id);
    }

    @Override
    public List<Comment> selCommentList(Integer actId) {
        List<Comment> comments = commentMapper.selCommentList(actId);
        for (Comment comment:comments) {
            Integer id = comment.getId();
            List<Comment> childComments = commentMapper.selChildCommentList(id);
            comment.setChildList(childComments);

        }
        return comments;
    }

    @Override
    public List<Comment> selChildCommentList(Integer pid) {
        return commentMapper.selChildCommentList(pid);
    }

    @Override
    public Integer selCommentCount(Integer actId) {
        return commentMapper.selCommentCount(actId);
    }

    @Override
    public int deleteCommentByActId(Integer actId) {
        return commentMapper.deleteCommentByActId(actId);
    }


    /**
     * 构建查询条件
     * @param searchMap
     * @return
     */
    private Example createExample(Map<String, Object> searchMap){
        Example example=new Example(Comment.class);
        Example.Criteria criteria = example.createCriteria();
        if(searchMap!=null){
            // 评论内容
            if(searchMap.get("comment")!=null && !"".equals(searchMap.get("comment"))){
                criteria.andLike("comment","%"+searchMap.get("comment")+"%");
            }
            // 活动图片
            if(searchMap.get("commentPic")!=null && !"".equals(searchMap.get("commentPic"))){
                criteria.andLike("commentPic","%"+searchMap.get("commentPic")+"%");
            }

            // 活动评论id
            if(searchMap.get("id")!=null ){
                criteria.andEqualTo("id",searchMap.get("id"));
            }
            // 活动id
            if(searchMap.get("activityId")!=null ){
                criteria.andEqualTo("activityId",searchMap.get("activityId"));
            }
            // 用户id
            if(searchMap.get("userId")!=null ){
                criteria.andEqualTo("userId",searchMap.get("userId"));
            }

        }
        return example;
    }

}
