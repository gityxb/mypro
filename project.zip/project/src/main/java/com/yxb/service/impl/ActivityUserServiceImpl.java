package com.yxb.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.yxb.dao.ActivityMapper;
import com.yxb.dao.ActivityUserMapper;
import com.yxb.dao.UserMapper;
import com.yxb.entity.PageResult;
import com.yxb.pojo.Activity;
import com.yxb.pojo.ActivityUser;
import com.yxb.pojo.User;
import com.yxb.service.ActivityUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ActivityUserServiceImpl implements ActivityUserService {

    @Autowired
    private ActivityUserMapper activityUserMapper;

    @Autowired
    private ActivityMapper activityMapper;

    @Autowired
    private UserMapper userMapper;

    /**
     * 返回全部记录
     * @return
     */
    public List<ActivityUser> findAll() {

        return activityUserMapper.selectAll();
    }

    /**
     * 分页查询
     * @param page 页码
     * @param size 每页记录数
     * @return 分页结果
     */
    public PageResult<ActivityUser> findPage(int page, int size) {
        PageHelper.startPage(page,size);
        Page<ActivityUser> activityUsers = (Page<ActivityUser>) activityUserMapper.selectAll();
        return new PageResult<ActivityUser>(activityUsers.getTotal(),activityUsers.getResult());
    }

    /**
     * 条件查询
     * @param searchMap 查询条件
     * @return
     */
    public List<ActivityUser> findList(Map<String, Object> searchMap) {
        Example example = createExample(searchMap);
        return activityUserMapper.selectByExample(example);
    }

    /**
     * 分页+条件查询
     * @param searchMap
     * @param page
     * @param size
     * @return
     */
    public PageResult<ActivityUser> findPage(Map<String, Object> searchMap, int page, int size) {
        PageHelper.startPage(page,size);
        Example example = createExample(searchMap);
        Page<ActivityUser> activityUsers = (Page<ActivityUser>) activityUserMapper.selectByExample(example);
        return new PageResult<ActivityUser>(activityUsers.getTotal(),activityUsers.getResult());
    }

    /**
     * 根据Id查询
     * @param id
     * @return
     */
    public ActivityUser findById(Integer id) {
        return activityUserMapper.selectByPrimaryKey(id);
    }

    /**
     * 新增
     * @param activityUser
     */
    public void add(ActivityUser activityUser) {
        activityUserMapper.insertSelective(activityUser);
    }

    /**
     * 修改
     * @param activityUser
     */
    public void update(ActivityUser activityUser) {
        activityUserMapper.updateByPrimaryKeySelective(activityUser);
    }

    /**
     *  删除
     * @param id
     */
    public void delete(Integer id) {
        activityUserMapper.deleteByPrimaryKey(id);
    }

    @Override
    public int selectUser(ActivityUser activityUser) {
        return activityUserMapper.selectUser(activityUser);
    }

    @Override
    public String[] selactUsers(Integer actId) {
        return activityUserMapper.selactUsers(actId);
    }

    @Override
    public ArrayList<ArrayList<User>> getInActUser(String username) {
        //获取出自己所有发布活动的id
        Integer[] integers = activityMapper.selActId(username);


        ArrayList<ArrayList<User>> actUserList = new ArrayList<ArrayList<User>>();
        
        //便历循环自己的发布活动的id
        for (int i = 0; i < integers.length; i++) {


            //创建一个List装user
            ArrayList<User> arrayList = new ArrayList<User>();

            //查出每个活动的id对应的参加的人
            String[] strings = activityUserMapper.selactUsers(integers[i]);

            //获取活动本身
            Activity activity = activityMapper.selectByPrimaryKey(integers[i]);
            String name = activity.getName();
            for (int j = 0; j < strings.length; j++) {

                User user = userMapper.selUserByName(strings[j]);
                if(user!=null){
                    user.setActivityName(name);
                    arrayList.add(user);
                }

            }
            if(!arrayList.isEmpty()){actUserList.add(arrayList);}
        }

        return actUserList;
    }

    @Override
    public int deleteTakeAct(Map<String, Object> mapOject) {
        return activityUserMapper.deleteTakeAct(mapOject);
    }

    @Override
    public int deleteByActivityId(Integer id) {
        return activityUserMapper.deleteByActivityId(id);
    }

    @Override
    public int deleteByUsername(String username) {
        return activityUserMapper.deleteByUsername(username);
    }

    @Override
    public Integer[] selActByUserName(String username) {
        return activityUserMapper.selActByUserName(username);
    }

    /**
     * 构建查询条件
     * @param searchMap
     * @return
     */
    private Example createExample(Map<String, Object> searchMap){
        Example example=new Example(ActivityUser.class);
        Example.Criteria criteria = example.createCriteria();
        if(searchMap!=null){
            // 是否已交押金(1已交，0未交)
            if(searchMap.get("isPay")!=null && !"".equals(searchMap.get("isPay"))){
                criteria.andLike("isPay","%"+searchMap.get("isPay")+"%");
            }

            // 用户活动表id
            if(searchMap.get("id")!=null ){
                criteria.andEqualTo("id",searchMap.get("id"));
            }
            // 活动id
            if(searchMap.get("activityId")!=null ){
                criteria.andEqualTo("activityId",searchMap.get("activityId"));
            }
            // 用户id
            if(searchMap.get("userId")!=null ){
                criteria.andEqualTo("userId",searchMap.get("userId"));
            }

        }
        return example;
    }

}
