package com.yxb.interceptor;

import com.alibaba.fastjson.JSON;
import com.yxb.entity.Result;
import com.yxb.util.JWTUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class JWTInterceptor implements HandlerInterceptor {


        public void afterCompletion(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, Exception arg3)
                throws Exception {
            // TODO Auto-generated method stub

        }

        public void postHandle(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, ModelAndView arg3)
                throws Exception {
            // TODO Auto-generated method stub

        }

        public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object arg2) throws IOException {
            // TODO Auto-generated method stub

            response.setContentType("application/json;charset=utf-8");
            String jwt = request.getHeader("Authorization");
            System.out.println("token:"+jwt);

                if (jwt == null||"".equals(jwt)) {
                    System.out.println("用户未登录，验证失败");
                    Result rst = new Result(401, "用户未登录");
                    String strRst = JSON.toJSONString(rst);

                    PrintWriter writer = response.getWriter();
                    writer.println(strRst);
                    writer.flush();
                    writer.close();
                    return false;
                } else {
                        Result verfy = JWTUtils.verfy(jwt);
                        if(verfy.getCode()==1){
                            Result rst = new Result(402, "token验证失效");
                            String strRst = JSON.toJSONString(rst);
                            PrintWriter writer = response.getWriter();
                            writer.println(strRst);
                            writer.flush();
                            writer.close();

                            return false;
                        }
                        return true;
                }
        }



    }


