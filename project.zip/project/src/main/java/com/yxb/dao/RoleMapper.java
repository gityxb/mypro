package com.yxb.dao;

import com.yxb.pojo.Role;
import tk.mybatis.mapper.common.Mapper;

public interface RoleMapper extends Mapper<Role> {

}
