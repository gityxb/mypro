package com.yxb.dao;

import com.yxb.entity.IdentityResult;
import com.yxb.pojo.User;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface UserMapper extends Mapper<User> {


    @Select("select count(*) from tb_user where username=#{username} and password=#{password}")
    public int verifyIdentity(@Param("username") String username,@Param("password") String password);

    @Select("select count(*) from tb_user where username=#{username}")
    public int verifyName(@Param("username") String username);

    @Select("select u.username,r.rname,r.power from   tb_user u join tb_role r on u.role_id = r.id where u.username=#{username} ")
    public IdentityResult getRole(@Param("username") String username);

    public int batchDelete(@Param("list")List<String> list);

    @Select("select u.user_id userId," +
            "u.username," +
            "u.phone," +
            "u.sex," +
            "u.head_pic headPic," +
            "u.nick_name nickName," +
            "u.user_level userLevel," +
            "u.points points," +
            "u.role_id roleId," +
            "u.email " +
            "from tb_user u where username = #{username}")
    public User selUserByName(@Param("username")String username);

    @Select("select u.user_id userId," +
            "u.username," +
            "u.phone," +
            "u.sex," +
            "u.head_pic headPic," +
            "u.nick_name nickName," +
            "u.user_level userLevel," +
            "u.points points," +
            "u.role_id roleId," +
            "u.email ," +
            "u.password " +
            "from tb_user u where username = #{username}")
    public User selPassByName(@Param("username")String username);
}
