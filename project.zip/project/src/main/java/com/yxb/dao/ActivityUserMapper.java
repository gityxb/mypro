package com.yxb.dao;

import com.yxb.pojo.ActivityUser;
import org.apache.ibatis.annotations.Select;
import tk.mybatis.mapper.common.Mapper;

import java.util.Map;

public interface ActivityUserMapper extends Mapper<ActivityUser> {

    public int selectUser(ActivityUser activityUser);

    public String[] selactUsers(Integer actId);

    public int deleteTakeAct(Map<String, Object> mapOject);

    public int deleteByActivityId(Integer id);

    public int deleteByUsername(String username);

    public Integer[] selActByUserName(String username);

}
