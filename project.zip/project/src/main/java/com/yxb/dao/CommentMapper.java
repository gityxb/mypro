package com.yxb.dao;

import com.yxb.pojo.Comment;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface CommentMapper extends Mapper<Comment> {
    public List<Comment> selCommentList(Integer actId);
    public List<Comment> selChildCommentList(Integer pid);
    public Integer selCommentCount(Integer actId);

    public int  deleteCommentByActId(Integer actId);

}
