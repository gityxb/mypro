package com.yxb.dao;

import com.yxb.pojo.Activity;
import com.yxb.pojo.PublicActUser;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface ActivityMapper extends Mapper<Activity> {
    public int updateSetStus(Activity activity);

    public PublicActUser selectByPicActUser(Integer id);

    public List<Activity> selActivity(String username);

    public List<Activity> selPicAct(String username);

    public Integer[] selActId(String username);

    public List<Activity> selByTime();

    public List<Activity> selByOrderCount();


}
