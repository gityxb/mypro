package com.yxb.dao;

import com.yxb.pojo.Message;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface MessageMapper extends Mapper<Message> {



    @Select("SELECT m.message message, " +
            "m.id id, " +
            "u.username username, " +
            "m.date date "  +
            "FROM tb_message m " +
            "LEFT JOIN tb_user u " +
            "on m.user_id=u.user_id ")
    List<Message> selectByExample(Object o);


    @Select("select * from tb_message where status = '0'")
    List<Message> findUnRead();

    @Select("select * from tb_message where status = '1'")
    List<Message> findRead();

    @Update("UPDATE tb_message set `status`=1 where id =#{id} ")
    int setStuts(Integer id);


}
