package com.yxb.controller;


import com.yxb.entity.PageResult;
import com.yxb.entity.Result;
import com.yxb.pojo.Message;
import com.yxb.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/message")
public class MessageController {

    @Autowired
    private MessageService messageService;

    @GetMapping("/findAll")
    public List<Message> findAll(){
        return messageService.findAll();
    }

    @GetMapping("/findUnRead")
    public List<Message> findUnRead(){
        return messageService.findUnRead();
    }

    @GetMapping("/findRead")
    public List<Message> findRead(){
        return messageService.findRead();
    }

    @GetMapping("/findPage")
    public PageResult<Message> findPage(int page, int size){
        return messageService.findPage(page, size);
    }

    @PostMapping("/findList")
    public List<Message> findList(@RequestBody Map<String,Object> searchMap){
        return messageService.findList(searchMap);
    }

    @PostMapping("/findPage")
    public PageResult<Message> findPage(@RequestBody Map<String,Object> searchMap,int page, int size){
        return  messageService.findPage(searchMap,page,size);
    }

    @GetMapping("/findById")
    public Message findById(Integer id){
        return messageService.findById(id);
    }


    @PostMapping("/add")
    public Result add(@RequestBody Message message){
        messageService.add(message);
        return new Result();
    }

    @PostMapping("/update")
    public Result update(@RequestBody Message message){
        message.setStatus("1");
        messageService.update(message);
        return new Result();
    }

    @GetMapping("/delete")
    public Result delete(Integer id){
        messageService.delete(id);
        return new Result();
    }

    @PostMapping("/setStuts")
    public Result setStuts(Integer id){
        int i = messageService.setStuts(id);
        if (i == 1) {
            return new Result();
        }

        return new Result(1,"更新失败");
    }

}
