package com.yxb.controller;

import com.yxb.entity.PageResult;
import com.yxb.entity.Result;
import com.yxb.pojo.User;
import com.yxb.service.ActivityUserService;
import com.yxb.service.UserService;
import com.yxb.util.Md5;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.UnsupportedEncodingException;
import java.util.*;
@CrossOrigin
@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private ActivityUserService activityUserService;

    @GetMapping("/findAll")
    public List<User> findAll(){
        return userService.findAll();
    }

    @GetMapping("/findPage")
    public PageResult<User> findPage(int page, int size){
        return userService.findPage(page, size);
    }

    @PostMapping("/findList")
    public List<User> findList(@RequestBody Map<String,Object> searchMap){
        return userService.findList(searchMap);
    }

    @PostMapping("/findPage")
    public PageResult<User> findPage(@RequestBody Map<String,Object> searchMap,int page, int size){

        return  userService.findPage(searchMap,page,size);
    }

    @GetMapping("/findById")
    public User findById(Integer userId){
        return userService.findById(userId);
    }


    @PostMapping("/add")
    public Result add(@RequestBody User user){
        String password = user.getPassword();
        user.setPassword(Md5.MD5(password));
//        user.setUserLevel(1);
//        user.setPoints(1);
        userService.add(user);
        return new Result();
    }

    @PostMapping("/update")
    public Result update(@RequestBody User user){
        userService.update(user);
        return new Result();
    }

    @PostMapping("/updatePassword")
    public Result updatePassword(@RequestBody Map<String,Object> map){


        String oldPassword = (String)map.get("oldPassword");
        String newPassword = (String)map.get("newPassword");
        String username = (String)map.get("username");

        //对比旧密码
        User user = userService.selPassByName(username);
        String password = user.getPassword();
        String pw = Md5.MD5(oldPassword);

        if(pw.equals(password)){
            user.setPassword(Md5.MD5(newPassword));
            userService.update(user);
            return new Result();
        }

        return new Result(1,"旧密码有误");

    }

    @GetMapping("/delete")
    public Result delete(Integer userId,String username) throws UnsupportedEncodingException {
        String s = new String(username.getBytes("iso-8859-1"), "utf-8");
        userService.delete(userId,s);
        return new Result();
    }

    @PostMapping("batchDelete")
    public Result batchDelete(@RequestBody List<String> list){
        int i = userService.batchDelete(list);
        if(i>=1){
            return new Result();

        }
        return new Result(1,"删除失败");
    }

    @GetMapping("/selUserByName")
    public User selUserByName(String username) throws UnsupportedEncodingException {
        String s = new String(username.getBytes("iso-8859-1"), "utf-8");
        return userService.selUserByName(s);

    }


}
