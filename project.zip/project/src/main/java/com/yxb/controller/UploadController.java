package com.yxb.controller;


import com.aliyun.oss.OSSClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.util.*;

@CrossOrigin
@RestController
@RequestMapping("/upload")
public class UploadController  {

@Autowired
private HttpServletRequest request;

    @RequestMapping("/native")
    public String nativeUpload(@RequestParam("file") MultipartFile file) throws IOException {
        System.out.println("...正在上传");
        String path = request.getSession().getServletContext().getRealPath("img2");
        System.out.println("path:" + path);
        String filePath = path + "/"+ UUID.randomUUID() + file.getOriginalFilename();
        System.out.println("filepath" + filePath);
        File desFile = new File(filePath);

        if (!desFile.getParentFile().exists()) {
            desFile.mkdirs();

            file.transferTo(desFile);

        }
        return "http://localhost:9102/img2/" + desFile.getName();

    }


    @Autowired
    private OSSClient ossClient;

    @PostMapping("/oss")
    public String ossUpload(@RequestParam("file") MultipartFile file,String floder){
        String bucketName="qingchengdianyxb";
        String fileName = floder+"/"+ UUID.randomUUID();
        try {
            ossClient.putObject(bucketName,fileName,file.getInputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return "https://"+bucketName+".oss-cn-shenzhen.aliyuncs.com/"+fileName;
    }

//    @PostMapping("/Multioss")
//    public List<Map<String ,String>> MultiossUpload(@RequestParam("file") MultipartFile[] files,String floder){
//        String bucketName="qingchengdianyxb";
//        List<Map<String ,String>> picList = new ArrayList<Map<String, String>>();
//        Map<String ,String> map = new HashMap<String ,String>();
//        for (int i = 0; i < files.length; i++) {
//            map.clear();
//
//            String fileName = floder+"/"+ UUID.randomUUID()+ files[i].getOriginalFilename();
//            try {
//                ossClient.putObject(bucketName,fileName,files[i].getInputStream());
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//            map.put("name",fileName);
//            map.put("url","https://"+bucketName+".oss-cn-shenzhen.aliyuncs.com/"+fileName);
//            picList.add(map);
//        }
//
//        return picList;
//    }

}
