package com.yxb.util;

import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.JWTCreator.Builder;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.auth0.jwt.interfaces.JWTVerifier;
import com.auth0.jwt.JWT;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class Jwtdemo{

//    @Scheduled(cron = "0/3 * * * * *")
//    public void testTask(){
//        System.out.println("呵呵1");
//    }
//
//    @Scheduled(cron = "0/3 * * * * *")
//    public void testTask1(){
//        System.out.println("呵呵2");
//    }
//    @Scheduled(cron = "0/3 * * * * *")
//    public void testTask2(){
//        System.out.println("呵呵3");
//
//    }
//
//    @Scheduled(cron = "0/3 * * * * *")
//    public void testTask3(){
//        System.out.println("呵呵4");
//    }

    //JWT验证token的密钥
//    private static final String JWT_SECRET = "your secret can't be exposed";
//
//    public static void main(String[] args) {
//        //签名算法，根据密钥，生成Algorithm实例，通常应用生命周期内都可以使用这个对象
//        Algorithm algorithm = Algorithm.HMAC256(JWT_SECRET);
//
//        //根据Algorithm生成token
//        Builder tokenBuilder = JWT.create();
//
//        //配置token的Header自定义部分
//        Map<String, Object> headers = new HashMap<>();
//        headers.put("myheader", "myheader");
//        tokenBuilder.withHeader(headers);
//
//        //配置token的PayLoad部分预定义字段
//        tokenBuilder.withIssuer("iss")
//                .withSubject("sub")
//                .withAudience("viewer1", "viewer2")
//                .withExpiresAt(new Date(System.currentTimeMillis() + 5000));
//
//        //配置PayLoad部分自定义字段
//        tokenBuilder.withClaim("name", "jack")
//                .withArrayClaim("pets", new String[] {"cat", "dog", "bird"});
//
//        //根据Alogrithm，签名后生成token
//        String token = tokenBuilder.sign(algorithm);
//        System.out.println("token : " + token);
//        token = token+"a";
//        //解密token看下内容
//        DecodedJWT decodedJWT = JWT.decode(token);
//        System.out.println("header : " + decodeBase64Url(decodedJWT.getHeader()));
//        System.out.println("payload : " + decodeBase64Url(decodedJWT.getPayload()));
//
//        //构造JWTVerifier，用于验证token，这里说明，
//        //签名及payload用来验证token，header的自定义字段则不用于验证
//        JWTVerifier jwtVerifier = JWT.require(algorithm)
//                .withIssuer("iss")
//                .withAudience("viewer1", "viewer2")
//                .acceptExpiresAt(System.currentTimeMillis() + 5000)
//                .withSubject("sub")
//                .withClaim("name", "jack") //可以尝试修改verifier，则下面的验证会抛异常
//                .withArrayClaim("pets", new String[] {"cat", "dog", "bird"})
//                .build();
//
//        //使用Verifier执行验证
//        try {
//            token = token.substring(0,token.length()-1);
//            DecodedJWT decodedJWT2 = jwtVerifier.verify(token);
//            System.out.println("payload again: " + decodeBase64Url(decodedJWT2.getPayload()));
//        }catch (Exception e){
//            System.out.println(e.getMessage());
//
//        }
//
//
//    }
//
//    private static String decodeBase64Url(String base64Url) {
//        return new String(Base64.getUrlDecoder().decode(base64Url));
//    }



}

