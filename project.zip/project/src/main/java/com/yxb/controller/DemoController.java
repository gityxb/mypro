package com.yxb.controller;

import com.alibaba.fastjson.JSON;
import com.yxb.entity.Result;
import com.yxb.util.JWTUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@RestController
@RequestMapping("/demo")
public class DemoController {

    @RequestMapping("/aa")
    public String gettaoken(HttpServletRequest request){
        String authorization = request.getHeader("Authorization");
        Result verfy = JWTUtils.verfy(authorization);
        String message = verfy.getMessage();
        System.out.println("message"+message);
        Map<String,String> messageMap = (Map) JSON.parseObject(message);
        String userId = messageMap.get("userId");
        return userId;
    }
}
