package com.yxb.controller;

import com.alibaba.fastjson.JSON;
import com.yxb.pojo.Activity;
import com.yxb.pojo.ActivityUser;
import com.yxb.service.ActivityService;
import com.yxb.service.ActivityUserService;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;


public class ActivityConsumer implements MessageListener {

    @Autowired
    private ActivityUserService activityUserService;

    @Autowired
    private ActivityService activityService;

    @Override
    public void onMessage(Message message) {
        String jsonString = new String(message.getBody());

        ActivityUser activityUser = JSON.parseObject(jsonString, ActivityUser.class);

        int i = activityUserService.selectUser(activityUser);
        if(i==0){ //判断是否已经存在

            Integer activityId = activityUser.getActivityId();
            Activity activity = activityService.findById(activityId);
            Integer count = activity.getCount();
            if(count<activity.getMaxCount()){//当前人数小于最大限制人数即可添加
                activityUserService.add(activityUser);
                count++;
                activity.setCount(count);
                activityService.update(activity);
            }
        }else{
            System.out.println("添加失败");
        }
        System.out.println(activityUser);
    }

}
