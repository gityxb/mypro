package com.yxb.controller;

import com.yxb.entity.IdentityResult;
import com.yxb.entity.Result;
import com.yxb.pojo.User;
import com.yxb.service.UserService;
import com.yxb.util.JWTUtils;
import com.yxb.util.Md5;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/login")
public class LoginController {


    @Autowired
    private UserService userService;

    @RequestMapping("/login")
    public IdentityResult index(@RequestBody  Map<String,String> param){

        int i = userService.verifyIdentity(param.get("username"), Md5.MD5(param.get("password")));

        if(i==1){   //判断用户是否存在

            IdentityResult identityResult = new IdentityResult();

            //将用户名一起加密后传递给前端
            String token = JWTUtils.createToken(param.get("username"));

            //获取该用户角色
            IdentityResult rst = userService.getRole(param.get("username"));

            //设置用户信息值
            identityResult.setCode(0);
            identityResult.setToken(token);
            identityResult.setRname(rst.getRname());
            identityResult.setPower(rst.getPower());
            identityResult.setUsername(rst.getUsername());
            return identityResult;
        }
        return new IdentityResult(1,"验证错误");
    }

    @PostMapping("/register")
    public Result update(@RequestBody User user){
        int i = userService.verifyName(user.getUsername());
        if(i>0){
            return new Result(403,"用户名已被注册");
        }
        String password = user.getPassword();
        user.setPassword(Md5.MD5(password));
        userService.add(user);
        return new Result();
    }
}
