package com.yxb.controller;




import org.apache.log4j.Logger;
import org.junit.Test;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class testController {

    @GetMapping("/aa")
    @ResponseBody
    public String test(){
        return"aa";
    }
    private static Logger log = Logger.getLogger(Test.class.getClass());
    @Test
    public void testLog(){
        log.debug("debug111");
        log.error("error111");
    }


}
