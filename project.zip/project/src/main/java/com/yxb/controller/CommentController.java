package com.yxb.controller;


import com.yxb.entity.PageResult;
import com.yxb.entity.Result;
import com.yxb.pojo.Comment;
import com.yxb.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.UnsupportedEncodingException;
import java.util.*;

@RestController
@RequestMapping("/comment")
public class CommentController {

    @Autowired
    private CommentService commentService;

    @GetMapping("/findAll")
    public List<Comment> findAll(){
        return commentService.findAll();
    }

    @GetMapping("/findPage")
    public PageResult<Comment> findPage(int page, int size){
        return commentService.findPage(page, size);
    }

    @PostMapping("/findList")
    public List<Comment> findList(@RequestBody Map<String,Object> searchMap){
        return commentService.findList(searchMap);
    }

    @PostMapping("/findPage")
    public PageResult<Comment> findPage(@RequestBody Map<String,Object> searchMap,int page, int size){
        return  commentService.findPage(searchMap,page,size);
    }

    @GetMapping("/findById")
    public Comment findById(Integer id){
        return commentService.findById(id);
    }


    @PostMapping("/add")
    public Result add(@RequestBody Comment comment){
        commentService.add(comment);
        return new Result();
    }

    @PostMapping("/update")
    public Result update(@RequestBody Comment comment){
        commentService.update(comment);
        return new Result();
    }

    @GetMapping("/delete")
    public Result delete(Integer id){
        commentService.delete(id);
        return new Result();
    }

    @GetMapping("/selByActId")
    public List<Comment> selCommentList(Integer actId){

        return commentService.selCommentList(actId);
    }

    @GetMapping("/selCommentCount")
    public Integer selCommentCount(Integer actId){
        return commentService.selCommentCount(actId);
    }

}
