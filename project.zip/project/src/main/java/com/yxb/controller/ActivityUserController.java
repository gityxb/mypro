package com.yxb.controller;
import com.yxb.entity.PageResult;
import com.yxb.entity.Result;
import com.yxb.pojo.Activity;
import com.yxb.pojo.ActivityUser;
import com.yxb.pojo.User;
import com.yxb.service.ActivityService;
import com.yxb.service.ActivityUserService;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.alibaba.fastjson.JSON;

import java.io.UnsupportedEncodingException;
import java.util.*;

@RestController
@RequestMapping("/activityUser")
public class ActivityUserController {

    @Autowired
    private ActivityUserService activityUserService;

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Autowired
    private ActivityService activityService;

    @GetMapping("/findAll")
    public List<ActivityUser> findAll() {
        return activityUserService.findAll();
    }

    @GetMapping("/findPage")
    public PageResult<ActivityUser> findPage(int page, int size) {
        return activityUserService.findPage(page, size);
    }

    @PostMapping("/findList")
    public List<ActivityUser> findList(@RequestBody Map<String, Object> searchMap) {
        return activityUserService.findList(searchMap);
    }

    @PostMapping("/findPage")
    public PageResult<ActivityUser> findPage(@RequestBody Map<String, Object> searchMap, int page, int size) {
        return activityUserService.findPage(searchMap, page, size);
    }

    @GetMapping("/findById")
    public ActivityUser findById(Integer id) {
        return activityUserService.findById(id);
    }


    @PostMapping("/add")
    public Result add(@RequestBody ActivityUser activityUser) {
        //已参加的所有活动id
        Integer[] integers = activityUserService.selActByUserName(activityUser.getUsername());

        //当前要添加的活动
        Integer activityId = activityUser.getActivityId();
        Date goTime1 = activityService.findById(activityId).getGoTime();

        ArrayList<Date> dates = new ArrayList<Date>();
        for (int i = 0; i < integers.length; i++) {
            Activity activity = activityService.findById(integers[i]);
            Date goTime = activity.getGoTime();
            dates.add(goTime);
        }

        //时间冲突解决方法
        if(dates.contains(goTime1)){
            return new Result(1,"时间冲突");
        }
        //排队加入消息队列
        rabbitTemplate.convertSendAndReceive("", "queue.activity", JSON.toJSONString(activityUser));
        return new Result();
    }

    @PostMapping("/update")
    public Result update(@RequestBody ActivityUser activityUser) {
        activityUserService.update(activityUser);
        return new Result();
    }

    @GetMapping("/delete")
    public Result delete(Integer id) {
        activityUserService.delete(id);
        return new Result();
    }

    @PostMapping("/selectUser")
    public Result selectUser(@RequestBody ActivityUser activityUser){
        int i = activityUserService.selectUser(activityUser);
        if(i==1){
            return new Result(0,"已参团");
        }
        return new Result(0,"未参团");


    }

    @GetMapping("/selactUsers")
    public String[] selactUsers(Integer actId){
        return activityUserService.selactUsers(actId);
    }

    @GetMapping("/getInActUsers")
    public ArrayList<ArrayList<User>> getInActUser(String username) throws UnsupportedEncodingException {
        String s = new String(username.getBytes("iso-8859-1"), "utf-8");
        return activityUserService.getInActUser(s);
    }

    @PostMapping("/deleteTakeAct")
    public Result deleteTakeAct(@RequestBody Map<String, Object> mapOject){

        Activity act = activityService.findById((Integer) mapOject.get("id"));
        long endTime = act.getEndTime().getTime();  //报名结束时间
        long nowTime = new Date().getTime();        //当前时间
        if(nowTime>endTime){
            return new Result(1,"报名结束无法退团");
        }

        int i = activityUserService.deleteTakeAct(mapOject);
        if(i==1){
            return new Result();
        }

        return new Result(1,"删除失败");

    }

}
