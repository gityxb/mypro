package com.yxb.controller;


import com.yxb.entity.PageResult;
import com.yxb.entity.Result;
import com.yxb.pojo.Activity;
import com.yxb.pojo.PublicActUser;
import com.yxb.service.ActivityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.UnsupportedEncodingException;
import java.util.*;

@RestController
@RequestMapping("/activity")
public class ActivityController {

    @Autowired
    private ActivityService activityService;


    @GetMapping("/findAll")
    public List<Activity> findAll(){
        return activityService.findAll();
    }

    @GetMapping("/findPage")
    public PageResult<Activity> findPage(int page, int size){
        return activityService.findPage(page, size);
    }

    @PostMapping("/findList")
    public List<Activity> findList(@RequestBody Map<String,Object> searchMap){
        return activityService.findList(searchMap);
    }

    @PostMapping("/findPage")
    public PageResult<Activity> findPage(@RequestBody Map<String,Object> searchMap,int page, int size){
        return  activityService.findPage(searchMap,page,size);
    }

    @GetMapping("/findById")
    public Activity findById(Integer id){
        return activityService.findById(id);
    }


    @PostMapping("/add")
    public Result add(@RequestBody Activity activity){
        activityService.add(activity);
        return new Result();
    }

    @PostMapping("/update")
    public Result update(@RequestBody Activity activity){
        activityService.update(activity);
        return new Result();
    }

    @GetMapping("/delete")
    public Result delete(Integer id){
        activityService.deleteAct(id);
        return new Result();
    }

    @PostMapping("/updataStus")
    public Result updataStus(@RequestBody Activity activity){
        int i = activityService.updateSetStus(activity);
        if(i>0){
            return new Result();
        }
        return new Result(1,"更新失败");
    }

    @GetMapping("/selectByPublicActUser")
    public PublicActUser selectByPublicActUser(Integer id){
        return activityService.selectByPicActUser(id);
    }

    @GetMapping("/selectUserActivity")
    public List<Activity> selectUserActivity(@RequestParam("username") String username) throws UnsupportedEncodingException {
        String s = new String(username.getBytes("iso-8859-1"), "utf-8");
        return activityService.selActivity(s);
    }

    @GetMapping("/selPicAct")
    public List<Activity> selPicAct(@RequestParam("username") String username) throws UnsupportedEncodingException {
        String s = new String(username.getBytes("iso-8859-1"), "utf-8");
        return activityService.selPicAct(s);
    }



    @GetMapping("selActId")
    public Integer[] selActId(@RequestParam("username") String username) throws UnsupportedEncodingException {
        String s = new String(username.getBytes("iso-8859-1"), "utf-8");
        return activityService.selActId(s);
    }


    @GetMapping("/selByTime")
    public List<Activity> selByTime(){
        return activityService.selByTime();
    }

    @GetMapping("/selByOrderCount")
    public List<Activity> selByOrderCount(){
        return activityService.selByOrderCount();
    }

//    @GetMapping("/hehe")
//    public Result deleteAct(Integer id) {
//        activityService.deleteAct(id);
//        return new Result();
//    }




}
