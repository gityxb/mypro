package com.yxb.pojo;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * comment实体类
 * @author Administrator
 *
 */
@Table(name="tb_comment")
public class Comment implements Serializable{

	@Id
	private Integer id;//活动评论id


	

	private String comment;//评论内容

	private String commentPic;//活动图片

	private Integer activityId;//活动id

	private String username;//用户id

	private Integer pid;//评论父id

	private Date createTime;//评论时间

	@Transient //非数据库字段
	private List<Comment> childList;//列表

	@Transient //非数据库字段
	private String headPic;//头像


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getCommentPic() {
		return commentPic;
	}

	public void setCommentPic(String commentPic) {
		this.commentPic = commentPic;
	}

	public Integer getActivityId() {
		return activityId;
	}

	public void setActivityId(Integer activityId) {
		this.activityId = activityId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getHeadPic() {
		return headPic;
	}

	public void setHeadPic(String headPic) {
		this.headPic = headPic;
	}

	public Integer getPid() {
		return pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public List<Comment> getChildList() {
		return childList;
	}

	public void setChildList(List<Comment> childList) {
		this.childList = childList;
	}
}
