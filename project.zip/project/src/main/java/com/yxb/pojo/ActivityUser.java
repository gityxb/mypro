package com.yxb.pojo;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
/**
 * activityUser实体类
 * @author Administrator
 *
 */
@Table(name="tb_activity_user")
public class ActivityUser implements Serializable{

	@Id
	private Integer id;//用户活动表id

	private Integer activityId;//活动id

	private String username;//用户名

	private String isPay;//是否已交押金(1已交，0未交)

	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getActivityId() {
		return activityId;
	}
	public void setActivityId(Integer activityId) {
		this.activityId = activityId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getIsPay() {
		return isPay;
	}
	public void setIsPay(String isPay) {
		this.isPay = isPay;
	}

	@Override
	public String toString() {
		return "ActivityUser{" +
				"id=" + id +
				", activityId=" + activityId +
				", username='" + username + '\'' +
				", isPay='" + isPay + '\'' +
				'}';
	}
}
