package com.yxb.entity;

import java.io.Serializable;

public class IdentityResult implements Serializable {

    public IdentityResult() {
    }

    public IdentityResult(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    private Integer code;//业务返回码  0：成功  1:错误

    private String token;//令牌

    private String rname;//返回用户角色

    private Integer power;//权限

    private String message;//消息

    private String username;//用户名

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getRname() {
        return rname;
    }

    public void setRname(String rname) {
        this.rname = rname;
    }

    public Integer getPower() {
        return power;
    }

    public void setPower(Integer power) {
        this.power = power;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "IdentityResult{" +
                "code=" + code +
                ", token='" + token + '\'' +
                ", rname='" + rname + '\'' +
                ", power=" + power +
                ", message='" + message + '\'' +
                ", username='" + username + '\'' +
                '}';
    }
}
