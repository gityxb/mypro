package com.yxb.entity;

import java.io.Serializable;
import java.util.List;

/**
 * 分页结果
 * @param <T>
 */
public class PageResult<T> implements Serializable {

    private Long total;//返回记录数
    private List<T> rows;//结果
    private Integer code=1;

    public PageResult(Long total, List<T> rows) {
        this.total = total;
        this.rows = rows;
    }

    public PageResult() {
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public Long getTotal() {
        return total;
    }

    public List<T> getRows() {
        return rows;
    }

    public void setRows(List<T> rows) {
        this.rows = rows;
    }

    public void setTotal(Long total) {
        this.total = total;
    }

}
