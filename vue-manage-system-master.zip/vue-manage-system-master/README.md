# vue-manage-system-master

## 安装步骤

```
cd vue-manage-system-master    // 进入模板目录
npm install         // 安装项目依赖

// 开启服务器，浏览器访问 http://localhost:8080
npm run serve

// 执行构建命令，生成的dist文件夹放在服务器下即可访问
npm run build
```


