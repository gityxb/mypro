<template>
	<el-row style="height: 100%">

            <div  style="padding: 20px;background: #eee;height: 100%" >
                <el-col style="height: 100%; " :span="4" >

                    <el-menu style="height: 100%;"
                            default-active="4"
                            class="el-menu-vertical-demo"
                            >
                        <el-menu-item index="1">
                            <i class="el-icon-lx-peoplefill"></i>
                            <span slot="title"><router-link style="color: #303133;" :to="{ path: '/PersonCenter' }">个人中心</router-link></span>
                        </el-menu-item>
                        <el-menu-item index="2">
                            <i class="el-icon-lx-edit"></i>
                            <span slot="title"><router-link style="color: #303133;" :to="{ path: '/Public' }">发布</router-link></span>
                        </el-menu-item>
                        <el-menu-item index="3">
                            <i class="el-icon-setting"></i>
                            <span slot="title"><router-link style="color: #303133;":to="{ path: '/ActivityManager' }">管理</router-link></span>
                        </el-menu-item>
                        <el-menu-item index="4">
                            <i class="el-icon-lx-group"></i>
                            <span slot="title"><router-link style="color: #303133;" :to="{ path: '/Publiced' }">已发布</router-link></span>
                        </el-menu-item>
                        <el-menu-item index="5">
                            <i class="el-icon-lx-roundcheckfill"></i>
                            <span slot="title"><router-link style="color: #303133;" :to="{ path: '/Enroll' }">我已报名</router-link></span>
                        </el-menu-item>
                        
                    </el-menu>

                </el-col>
                <el-col :span="20" style="background: white;padding: 30px 20px;height: 400px;overflow-y: scroll;">
                    <el-table :data="activityList" border style="width: 100%">
                        <el-table-column prop="id" label="活动id" width="90"></el-table-column>
                        <!-- <el-table-column prop="categoryId" label="活动类型" width="80"></el-table-column> -->
<!--                        <el-table-column prop="description" label="活动简介" width="80"></el-table-column>-->
                        <el-table-column prop="name" label="活动名称" width="90"></el-table-column>
                        <el-table-column prop="address" label="活动地点" width="90"></el-table-column>
                        <el-table-column prop="count" label="当前人数" width="90"></el-table-column>
<!--                        <el-table-column prop="maxCount" label="最多人数限制" width="80"></el-table-column>-->
<!--                        <el-table-column prop="minCount" label="最少拼团人数" width="80"></el-table-column>-->
                        <el-table-column prop="startTime" :formatter="formatter"  label="开始时间" width="90"></el-table-column>
                        <el-table-column prop="endTime" :formatter="formatter1" label="结束时间" width="90"></el-table-column>
                        <el-table-column prop="goTime" :formatter="formatter3" label="出发时间" width="90"></el-table-column>
                        <el-table-column prop="status" :formatter="formatter2" label="审核状态" width="90"></el-table-column>
<!--                        <el-table-column prop="cash" label="押金" width="80"></el-table-column>-->

                        <el-table-column
                                label="操作"  >
                            <template slot-scope="scope">
                                <el-button @click="showDetail(scope.row.id)"  type="text" >查看</el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                </el-col>
                <div style="clear: both"></div>
            </div>
            <div class="add-form">
                    <!--弹出窗口-->
                    <el-dialog  title="编辑" :visible.sync="formVisible" >
                        <el-form label-width="80px">
                            
                            <el-form-item label="活动名称"><div>{{pojo.name}}</div></el-form-item>
                            <el-form-item label="活动地点"><div>{{pojo.address}}</div></el-form-item>
                            <el-form-item label="当前人数"><div>{{pojo.count}}</div></el-form-item>
                            <el-form-item label="活动图片">
                                <div>
                                    <img style="width:150px;height:100px;" :src="pojo.picture" alt="">
                                </div>
                            </el-form-item>
                            <el-form-item label="活动简介"><div>{{pojo.description}}</div></el-form-item>
                            <el-form-item label="最多人数"><div>{{pojo.maxCount}}</div></el-form-item>
                            <el-form-item label="最少人数"><div>{{pojo.minCount}}</div></el-form-item>
                            <el-form-item label="报名开始"><div>{{pojo.startTime|formatTime}}</div></el-form-item>
                            <el-form-item label="报名结束"><div>{{pojo.endTime|formatTime}}</div></el-form-item>
                            <el-form-item label="联系方式"><div>{{pojo.username}}</div></el-form-item>
                            <el-form-item label="押金"><div>{{pojo.cash}}￥</div></el-form-item>
                            
                            <div style="clear: both"></div>
                        </el-form>
                    </el-dialog>
                </div>


    </el-row>
</template>
<script type="text/javascript">
    export default {
  
    data() {
        return {
                activityList: [],
                pojo:{},
                formVisible:false,
            }
    },
    created() {
        this.fetchData();
    },
    methods:{
            fetchData (){
                let username = localStorage.getItem("username");
                this.axios.get(`/activity/selPicAct?username=${username}`).then(response => {
                    this.activityList = response.data;
                });
            },
            formatter(row, column){
                return this.moment(row.startTime).format("YYYY-MM-DD")
            },
            formatter1(row, column){
                return this.moment(row.endTime).format("YYYY-MM-DD")
            },
            formatter3(row, column){
                return this.moment(row.goTime).format("YYYY-MM-DD")
            },
            formatter2(row, column){
                return row.status=="true"?"通过":"未审核";

            },
            showDetail (id){
              
                this.formVisible = true // 打开窗口
                // 调用查询
                this.axios.get(`/activity/findById?id=${id}`).then(response => {
                    this.pojo = response.data;
                    this.formVisible = true;
                    // this.imageUrl=this.pojo.image //显示图片  如页面有图片上传功能放开注释
                })
            },
            
        }
};
</script>
<style type="text/css" scoped>
	.el-menu a{
		display: inline-block;
		width: 100%;
		height: 100%;
	}
</style>