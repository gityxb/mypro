<template>
    <el-row style="height: 100%">
        <div style="padding: 20px;background: #eee;height: 100%">
            <el-col style="height: 100%; " :span="4">
                <el-menu style="height: 100%;"
                            default-active="2"
                            class="el-menu-vertical-demo"
                            >
                        <el-menu-item index="1">
                            <i class="el-icon-lx-peoplefill"></i>
                            <span slot="title"><router-link style="color: #303133;" :to="{ path: '/PersonCenter' }">个人中心</router-link></span>
                        </el-menu-item>
                        <el-menu-item index="2">
                            <i class="el-icon-lx-edit"></i>
                            <span slot="title"><router-link style="color: #303133;" :to="{ path: '/Public' }">发布</router-link></span>
                        </el-menu-item>
                        <el-menu-item index="3">
                            <i class="el-icon-setting"></i>
                            <span slot="title"><router-link style="color: #303133;":to="{ path: '/ActivityManager' }">管理</router-link></span>
                        </el-menu-item>
                        <el-menu-item index="4">
                            <i class="el-icon-lx-group"></i>
                            <span slot="title"><router-link style="color: #303133;" :to="{ path: '/Publiced' }">已发布</router-link></span>
                        </el-menu-item>
                        <el-menu-item index="5">
                            <i class="el-icon-lx-roundcheckfill"></i>
                            <span slot="title"><router-link style="color: #303133;" :to="{ path: '/Enroll' }">我已报名</router-link></span>
                        </el-menu-item>
                        
                    </el-menu>
            </el-col>
            <el-col :span="20" style="background: white;padding: 30px 20px;height: 400px;overflow-y: scroll;padding-right:400px;">
                <el-form :model="pojo"    :rules="rules" ref="pojo" label-width="80px" style="height: 100%">
                    
                    <el-form-item label="活动封面" style="float:none;" prop="picture">
                        <!-- <el-upload
                                class="upload-demo"
                                action="/upload/oss?floder=activityPic"
                                :on-success="handleAvatarSuccess"
                                :on-preview="handlePreview"
                                :on-remove="handleRemove"
                                list-type="picture-card">

                            <el-button size="small" type="primary">点击上传</el-button>
                            <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div>
                        </el-upload>
                        <el-dialog :visible.sync="dialogVisible" size="tiny">
                            <img width="100%" :src="dialogImageUrl" alt="">
                        </el-dialog> -->


                        <el-upload style="width:100px;height:100px" class="avatar-uploader" 
                                    action="http://localhost:9102/upload/oss?floder=activityPic" 
                                    :show-file-list="false" 
                                    :on-success="handleAvatarSuccess" 
                                    :before-upload="beforeAvatarUpload"
                                    :headers="myHeaders">
                                    <img v-if="dialogImageUrl" :src="dialogImageUrl" class="avatar">
                                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                        </el-upload>

                        <!-- <el-input v-model="pojo.picture" hidden="true"></el-input> -->
                    </el-form-item>
                    <el-form-item label="活动类型" prop="categoryId">
                        <el-select v-model="pojo.categoryId" placeholder="请选择">
                            <el-option v-for="item in Categoryoptions"
                            :key="item.id" 
                            :label="item.categoryName" 
                            :value="item.id">
                            </el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="活动名称" prop="name">
                        <el-input v-model="pojo.name"></el-input>
                    </el-form-item>
                    <el-form-item label="集合地点" prop="collectionSite">
                        <el-input v-model="pojo.collectionSite"></el-input>
                    </el-form-item>
                    <el-form-item label="活动地点" prop="address">
                        <el-input v-model="pojo.address"></el-input>
                    </el-form-item>

                   <!--  <el-form-item label="当前人数">
                       <el-input v-model="pojo.count"></el-input>
                       <el-input-number v-model="pojo.count" @change="handleChange" :min="0" :max="100" label="描述文字"></el-input-number>
                   </el-form-item> -->
                   <el-form-item label="最少人数" prop="minCount">
                        <!-- <el-input v-model="pojo.minCount"></el-input> -->
                        <el-input-number size="small" v-model="pojo.minCount" :min="3" :max="10"></el-input-number>
                    </el-form-item>
                    <el-form-item label="最多人数"  prop="maxCount">
                       <el-input-number size="small" v-model="pojo.maxCount" :min="3" :max="10"></el-input-number>
                        
                        <!-- <el-input v-model="pojo.maxCount"></el-input> -->
                    </el-form-item>
                    
                    <el-form-item label="报名时间" >
                        <!-- <el-input v-model="pojo.startTime"></el-input>
                    </el-form-item>
                    <el-form-item label="结束时间">
                        <el-input v-model="pojo.endTime"></el-input> -->
                          <div class="block">
                           
                            
                            <el-date-picker
                            @change="time1"
                              v-model="pojo.timeLimit"
                              type="daterange"
                              value-format="yyyy-MM-dd"
                              range-separator="至"
                              start-placeholder="开始日期"
                              end-placeholder="结束日期"
                              align="right">
                            </el-date-picker>
                        </div>

                    </el-form-item>
                    <el-form-item label="出发日期" prop="goTime">
                        <el-date-picker style="width:200px;"
                          size="mini"
                          v-model="pojo.goTime"
                          type="date"
                          placeholder="选择日期">
                        </el-date-picker>
                    </el-form-item>
                    <!-- <el-form-item label="审核状态">
                        <el-input v-model="pojo.status"></el-input>
                    </el-form-item> -->
                    <!-- <el-form-item label="押金">
                        <el-input v-model="pojo.cash"></el-input>
                        <el-input-number v-model="pojo.cash" controls-position="right" @change="handleChange" :min="0" :max="100"></el-input-number>
                    </el-form-item> -->
                    <el-form-item label="活动简介" prop="description">
                        <el-input type="textarea" v-model="pojo.description"></el-input>
                    </el-form-item>
                    <el-form-item>
                        <el-button type="primary" @click="save('pojo')">立即创建</el-button>
                        <el-button @click="clear">清空</el-button>
                    </el-form-item>
                </el-form>
            </el-col>
            <div style="clear: both"></div>
        </div>
    </el-row>
</template>
<script>
let token =  localStorage.getItem('token') 

export default {
    data() {

        return {
            dialogImageUrl:"",//预览图片
            dialogVisible: false,
            Categoryoptions: [],
            tableData: [],
            currentPage: 1,
            total: 10,
            size: 10,
            searchMap: {},
            pojo: {count:0,cash:0,categoryId:null},
            formVisible: false,
            imageUrl: '',
            myHeaders: {Authorization: token},
     
            rules: {
                categoryId: [
                        { required: true, message: '请选择分类名称', trigger: 'change' },
                        
                    ],
                    name: [
                        { required: true, message: '活动名不能为空', trigger: 'blur' },
                        { message: '不能为空', trigger: 'blur' }
                    ],
                    collectionSite: [
                        { required: true, message: '集合地点不能为空', trigger: 'blur' },
                        
                    ],
                    address: [
                        { required: true, message: '活动地址不能为空', trigger: 'blur' },
                        
                    ],
                    minCount:[
                         { required: true, message: '最少人数不能为空', trigger: 'change' },
                        
                    ],
                    maxCount:[
                         { required: true, message: '最多人数不能为空', trigger: 'change' },
                      
                    ],
                    goTime:[
                         { type: 'date', required: true, message: '请选择出发日期', trigger: 'change' }
                    ],
                    description:[
                         { required: true, message: '简介不能为空', trigger: 'blur' },
                        { message: '不能为空', trigger: 'blur' }
                    ],
                    timeLimit:[
                         { type: 'date', required: true, message: '请选择时间', trigger: 'change' }
                    ],
                    
                },

        }
    },
    created() {
        this.fetchCategoryData();
        
    },
    methods: {
        fetchCategoryData() { 
            this.axios.get(`/category/findAll`).then(response => {
                this.Categoryoptions = response.data;
            });
        },
        time1(value){
            this.pojo.startTime=value[0]
            this.pojo.endTime=value[1]
        } ,  
        handleChange(value) {
            console.log(value);
        },
        save(form) {  //保存添加

            this.$refs[form].validate((valid) => {
              if (valid) {
                    if(this.pojo.startTime==""&&this.pojo.startTime==null){
                        this.$message.error('开始报名时间不为空');
                        return;
                    }
                    if(this.pojo.endTime==""&&this.pojo.endTime==null){
                        this.$message.error('结束报名时间不为空');
                        return;
                    }
                    this.pojo.username = localStorage.getItem('username')
            
                    this.axios.post(`/activity/${this.pojo.id==null?'add':'update'}`, this.pojo).then(response => {
                    console.log(response);
                    if (response.data.code===0) {
                        this.$message.success('创建成功');
                        this.$router.push('/');
                    }else{
                        alert(response.data.message)
                    }
                });
              } else {
                return false;
              }
            });
            
            
            // this.pojo.image= this.imageUrl; //如页面有图片上传功能放开注释
            
        },
        beforeAvatarUpload(file) {
            // const isJPG = file.type === 'image/jpg';
            // const isLt2M = file.size / 1024 / 1024 < 2;
            //
            // if (!isJPG) {
            //     this.$message.error('上传头像图片只能是 JPG 格式!');
            // }
            // if (!isLt2M) {
            //     this.$message.error('上传头像图片大小不能超过 2MB!');
            // }
            // return isJPG && isLt2M;
        },
        handleAvatarSuccess(res, file){
           console.log(file)
            
            this.dialogImageUrl = file.response;
            
            this.pojo.picture = file.response;
            console.log(file.response)
            console.log(file.response.message)

        },
        clear(){
            this.pojo = {}
        }

    }
}
</script>
<style scoped>
.el-menu a {
    display: inline-block;
    width: 100%;
    height: 100%;
}

div[data-v-57468743] {
    height: 100%;
}

.el-input {
    width: 400px;
}

.el-form-item {
    float: left;
}

.el-input__inner {
    height: 40px;
    line-height: 32px;
}

.el-textarea {
    width: 600px;

}
.avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
}

.avatar-uploader .el-upload:hover {
    border-color: #409EFF;
}

.el-upload--text {
    width: 100px;
    height: 100px;
}

.avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 100px;
    height: 100px;
    line-height: 100px;
    text-align: center;
}

.avatar {
    width: 100px;
    height: 100px;
    display: block;
}
</style>