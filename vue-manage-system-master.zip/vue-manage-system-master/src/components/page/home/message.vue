<template>
    <div style="height:500px;overflow-y:scroll;">
        <div  style="color:rgb(74, 74, 74);padding:30px 0px 0px 30px;">
            留言反馈
        </div>
        <div>&nbsp;</div>
        <div style="padding:0px 0px 0px 30px;"><span>标题:</span><el-input v-model="title" placeholder="请输入标题" style="width:200px;"></el-input></div>
        <div class="container" style="border:none;width:1000px;height:100px;padding:10px 0px 0px 30px;">
            <quill-editor ref="myTextEditor" v-model="content" :options="editorOption"></quill-editor>
            <el-button class="editor-btn" type="primary" @click="submit">提交</el-button>
        </div>
        <div style="clear:both;"></div>
    </div>
</template>

<script>
    import 'quill/dist/quill.core.css';
    import 'quill/dist/quill.snow.css';
    import 'quill/dist/quill.bubble.css';
    import { quillEditor } from 'vue-quill-editor';
    export default {
        name: 'editor',
        data: function(){
            return {
                content: '',
                title:'',
                editorOption: {
                    placeholder: 'Hello World'
                },
                pojo:{}
            }
        },
        components: {
            quillEditor
        },
        methods: {
            onEditorChange({ editor, html, text }) {
                this.content = html;
            },
            submit(){

                this.pojo.username = localStorage.getItem("username");
                this.pojo.message = this.content;
                this.pojo.title = this.title;
                this.pojo.status = 0;
                this.axios.post(`/message/add`,this.pojo).then(response=>{
                    if(response.data.code==0){
                        this.$message.success('提交成功！');
                        this.pojo = {}

                    }
                })
                console.log(this.content);
            }
        }
    }
</script>
<style scoped>
    .editor-btn{
        margin-top: 20px;
    }

</style>