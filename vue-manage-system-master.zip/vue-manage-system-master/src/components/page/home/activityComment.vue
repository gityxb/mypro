<template>
	<el-row style="height: 100%">
            <div  style="padding: 20px;background: #eee;height: 100%" >
                <el-col style="height: 100%; " :span="4" >

                    <el-menu style="height: 100%;"
                            default-active="2"
                            class="el-menu-vertical-demo"
                            >
                        <el-menu-item index="1">
                            <i class="el-icon-menu"></i>
                            <span slot="title"><router-link style="color: #303133;" :to="{ path: '/PersonCenter' }">个人中心</router-link></span>
                        </el-menu-item>
                        <el-menu-item index="2">
                            <i class="el-icon-menu"></i>
                            <span slot="title"><router-link style="color: #303133;" :to="{ path: '/Public' }">发布</router-link></span>
                        </el-menu-item>
                        <el-menu-item index="3">
                            <i class="el-icon-setting"></i>
                            <span slot="title"><router-link style="color: #303133;":to="{ path: '/ActivityManager' }">管理</router-link></span>
                        </el-menu-item>
                        <el-menu-item index="4">
                            <i class="el-icon-setting"></i>
                            <span slot="title"><router-link style="color: #303133;" :to="{ path: '/Publiced' }">已发布</router-link></span>
                        </el-menu-item>
                        <el-menu-item index="5">
                            <i class="el-icon-setting"></i>
                            <span slot="title"><router-link style="color: #303133;" :to="{ path: '/Enroll' }">我已报名</router-link></span>
                        </el-menu-item>
                        
                    </el-menu>

                </el-col>
                <el-col  :span="20" style="background: white;padding: 30px 20px;height: 400px;overflow-y: scroll;">
                  <div v-if="show">
                    <el-row>
                        <el-col :span="24">
                            <div class="grid-content">
                                <el-tag>个人中心</el-tag>
                            </div>
                        </el-col>
                    </el-row>

                    <div>&nbsp;</div>
                    <el-row>
                        <el-col :span="4"><img style="height:150px;width:150px;" :src="user.headPic" alt=""></el-col>
                        <el-col :span="16">
                            <div class="userdata">
                                <p>用户名字：{{user.username}}</p>
                                <p>性别：{{user.sex |formatSex}}</p>
                                <p>手机号码：{{user.phone}}</p>
                                <p>邮件：{{user.email}}</p>
                   
                            </div>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="24">
                            <div class="grid-content bordershadow shadowred ">
                                <el-button  type="danger">修改密码</el-button>
                                <div class="stuts" id="stuts">
                                    <el-input class="pweipt" placeholder="由数字和26个英文字母组成的字符串"  :show-password="true"></el-input>
                                    <el-button >提交</el-button>
                                </div>
                            </div>
                        </el-col>
                    </el-row>
                </div>
                <div v-show="!show"><el-tag>个人中心</el-tag><p  style="text-align:center;color:rgba(105, 105, 102, 1);margin-top:100px;">暂无数据</p></div>
                </el-col>
                <div style="clear: both"></div>
            </div>


    </el-row>
</template>
<script type="text/javascript">
    export default {
  
    data() {
        return {
               user:{},
                show:true
            }
    },
  
    created() {
       this.getUserData();
    },
    methods:{
           getUserData(){
            let username = localStorage.getItem("username");
            this.axios.get(`/user/selUserByName?username=${username}`).then(response=>{
                this.user = response.data
                if(response.data.code==401){this.show = false}
            })
           }
            

        }
};
</script>
<style type="text/css" scoped>
.el-menu a{
		display: inline-block;
		width: 100%;
		height: 100%;
	}
	a{
		color: #303133;
	}
.pl{width:90%;border:1px solid #e8e8e8;padding:4px;border-radius:5px;margin-left:8%;position:relative;margin-top:20px}
.tx{position:absolute;top:0px;left:-67px;width:55px;height:50px;background-image:url(../../../assets/img/tx.png);background-repeat:no-repeat;background-position:right 10px;padding-right:12px}
.tx img{width:100%;border-radius:45px}
.pl ul{padding:0px 20px;line-height:26px;margin:unset}
.plbg{background-color:#fafafa;border-bottom:1px dotted #DCDCDC}
.z13{font-size:13px}
.f{float:left}
.jl{color:#ff7800;padding-left:20px;display:none}
.r{float:right}
.dr{clear:right}
.pl .plul{word-wrap:break-word;padding-top:10px;padding-bottom:10px;font-size:14px;background-color:#fafafa}
.hf{float:right;font-size:12px;line-height:26px}
.tx2{width:45px;left:-57px}
.userdata p{
    font-size: 16px;
    padding-bottom: 14px;
}

</style>