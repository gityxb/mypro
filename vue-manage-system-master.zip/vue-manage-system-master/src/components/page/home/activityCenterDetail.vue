<template>
    <div style="height: 600px;overflow-y:scroll;">
        <el-row style="height: 600px;background:#eee;padding:0 20px;margin-buttom:10px;">
            <el-col :span="16" style="margin-top:20px;height:500px;">
                <div style="margin-right: 40px;">
                    <el-row>
                        <el-col :span="24">
                            <div style="height: 300px;background: white;margin: 30px 0">
                                <div style="padding: 20px;">
                                    <el-row>
                                        <h1 style="border-bottom: 1px solid #c7c7c7;padding: 20px 0">{{activity.name}}</h1>

                                        <el-col :span="12" >
                                            <div style="color: #909399;font-size:14px;">

                                                <p style="padding:8px 0;padding-top:10px;"><span>活动名称:</span>&nbsp;&nbsp;&nbsp;<span style="color: #4e82e6">{{activity.name}}</span></p>
                                                <p style="padding:8px 0;"><span>出发时间:</span>&nbsp;&nbsp;&nbsp;<span style="color: #4e82e6">{{activity.goTime|formatTime}}</span></p>
                                                <p style="padding:8px 0;"><span>联系电话:</span>&nbsp;&nbsp;&nbsp;<span style="color: #4e82e6">{{activity.phone}}</span></p>
                                                <p style="padding:8px 0;"><span>集合地点:</span>&nbsp;&nbsp;&nbsp;<span style="color: #4e82e6">{{activity.collectionSite}}</span></p>
                                                <p style="padding:8px 0;"><span>活动地点:</span>&nbsp;&nbsp;&nbsp;<span style="color: #4e82e6">{{activity.address}}</span></p>
                                            </div>
                                        </el-col>
                                        <el-col :span="12">
                                            <div class="activityPic" >
                                                                                        <img style="width:300px;height:150px;" :src="activity.picture">
                                                <!--                                        <p><span>活动名称</span>&nbsp;&nbsp;<span>游洞庭湖</span></p>-->
                                                <!--                                        <p><span>联系电话</span>&nbsp;&nbsp;<span>18312329843</span></p>-->
                                                <!--                                        <p><span>活动地点</span>&nbsp;&nbsp;<span>广东广州</span></p>-->
                                            </div>
                                        </el-col>
                                    </el-row>

                                </div>
                            </div>
                        </el-col>
                        <el-col :span="24">
                            <div style="height: 180px;background: white;">
                                <el-row>
                                    <el-col :span="24">
                                        <div style="padding: 20px;">
                                            <div>
                                                <h3 style="border-bottom:1px solid #c7c7c7 ">活动简介</h3>

                                                <p style="font-size: 14px;color: #7a7a7a;padding-top:14px;">{{activity.description}}</p>
                                            </div>
                                        </div>
                                    </el-col>
                                </el-row>
                            </div>
                        </el-col>
                    </el-row>
                    <el-row>

                    </el-row>
                </div>
            </el-col>
            <el-col :span="8" style="margin-top:80px;height:500px;">
                <h4 style="color: #494949;margin-bottom:20px;">报名</h4>
                <div style="height: 400px;background: white;padding: 20px">
                    <p style="margin-top:20px;">
                        <span style="color: rgba(144, 147, 150, 1)">活动开始 :</span> 
                        <span style="color: rgb(64, 158, 255)">{{activity.startTime|formatTime}}
                        </span>
                    </p>
                    <p style="margin-bottom: 20px;margin-top:20px;">
                        <span style="color: rgba(144, 147, 150, 1)">活动倒计时 :</span> 
                        <span style="color: rgb(64, 158, 255)">{{timeEnd}}
                        </span>
                    </p>
                    <p style="margin-bottom: 20px;font-size:12px;">
                        <span style="color: rgba(144, 147, 150, 1)">上限人数:</span> 
                        <span style="color: rgb(64, 158, 255)">{{activity.maxCount}}
                        </span>
                        &nbsp;
                        <span style="color: rgba(144, 147, 150, 1)">最少人数:</span> 
                        <span style="color: rgb(64, 158, 255)">{{activity.minCount}}
                        </span>
                    </p>
                    <p style="margin-bottom: 50px;font-size:12px;">
                        <span style="color: rgba(144, 147, 150, 1)">已报名:</span> 
                        <span style="color: rgb(64, 158, 255)">{{activity.count}}
                        </span>
                    </p>
                    <p>
                        <el-button type="primary" @click="inroll(activity.id)" :disabled="btnStus">开始报名</el-button>&nbsp;
                    <span style="color: red;font-size: 14px;margin-top:10px;">{{tip}}</span>
                </p>
                    
                </div>
            </el-col>
            <div style="clear:both"></div>
        </el-row>

        <div style="padding:0 20px;background:#eee;width: 66%;">
            <div style="height:700px;overflow:scroll;background:white;">

                <div style="border-bottom:1px solid #eee;border-left:4px solid #3cb371;font-size:20px;padding:20px;">&nbsp;评论&nbsp;<span style="font-size:15px;">({{count}})</span></div>  
                <div>
                    <div class="pl" v-for="list in commentList">
                        <div class="tx"><a href="#">
                            <img :src="list.headPic" height="55" width="45"></a></div>
                        <ul class="plbg">
                            <div class="f z13">{{list.username}}<span class="jl">0</span></div>
                            <div class="r"><span class="z13">{{list.createTime|formatTimeh}}</span></div>
                            <div class="dr"></div>
                        </ul>
                        <ul class="plul">
                            <p>{{list.comment}}</p>
                            <ul v-for="childList in list.childList ">
                                <div class="pl ">
                                    <div class="tx tx2"><a href="http://www.jq22.com/mem639828">
                                        <img height="45" width="45" :src="childList.headPic"></a></div>
                                    <ul class="plbg plbg2">
                                        <div class="f">{{childList.username}}<span class="jl">0</span></div>
                                        <div class="r"><span class="z12">{{childList.createTime|formatTimeh}}</span></div>
                                        <div class="dr"></div>
                                    </ul>
                                    <ul style="padding-top: 10px; padding-bottom: 10px; word-wrap: break-word; width: 100%">
                                        <p>{{childList.comment}}</p>
                                    </ul>
                                </div>
                            </ul>
                            
                            <a type="text" style="cursor:pointer;color:#00abff" @click="showOrHide(list.id)" class="hf" name="41517">回复
                            </a>
                                
                          
                            <div v-show="flag1==list.id">
                                <div class="lyhf"></div>
                                <div class="dr"></div>
                                <el-input  type="textarea" v-model="subContent"  placeholder="您有什么想法要说的吗？"></el-input>
                                <el-button type="primary" @click="childSubmit(list.id,list.activityId)" style="float:right;margin-top:10px;">评论</el-button>
                            </div>
                            <div style="clear:both;"></div>
                        </ul>
                    </div>

                </div>
                <div style="margin:20px;padding-bottom:50px;">
                    <el-input type="textarea" v-model="comment.comment"  placeholder="您有什么想法要说的吗？"></el-input>
                      <el-button style="float:right;margin-top:10px;" type="success" @click="PublicComment(activity.id)">发表评论</el-button>
                      <div style="clear:both;"></div>
                </div>

            </div>
        </div>
        <div style="clear:both;"></div>
   </div> 
</template>
<script>
    export default{
        data() {
            return {
                subContent:"",  //子评论
                comment:{comment:""},     //评论对象
                commentList:[], //评论列表
                activity:{},    //活动对象
                flag:false,     //定时器
                timeEnd:'',     //倒计时显示
                btnStus:false,  //评论框按钮
                addActUser:{},  //参加活动对象
                tip:"",         //提示信息
                flag1:0,        //
                count:0,
            }
        },
        methods: {
            getCommentCount(){ //获取评论数
                this.axios.get(`/comment/selCommentCount?actId=${this.$route.query.actId}`).then(response=>{
                    if(response.data>=1){
                        this.count = response.data
                    }
                })
            },
            childSubmit(id,actId){ //子评论
                    if(this.subContent=="")
                    {
                        this.$message.error('评论不能为空'); return;
                    }

                    this.comment.pid = id;
                    this.comment.comment = this.subContent;
                    this.comment.username = localStorage.getItem("username");
                    this.comment.activityId = actId;
                    this.axios.post(`/comment/add`,this.comment).then(response=>{
                        if(response.data.code==0){
                            this.getCommentData()
                            this.subContent="";
                            this.comment={};
                        }
                    })
                

            },
            showOrHide(val){ //显示或者隐藏评论框
                if(this.flag1==val){
                    this.flag1=null;
                }else{
                    this.flag1 = val;
                }
                
            },
            getCommentData(){  //获取评论数据
                this.axios.get(`/comment/selByActId?actId=${this.$route.query.actId}`).then(response=>{
                    this.commentList  = response.data
                    console.log(response)
                })
            },
            PublicComment(val){  //发表评论
                    if(this.comment.comment=="")
                    {

                        this.$message.error('评论不能为空'); return;
                    }
                    this.comment.activityId = val;
                    this.comment.pid = 0;
                    this.comment.username = localStorage.getItem("username"); 
                    this.axios.post(`/comment/add`,this.comment).then(response=>{
                        if(response.data.code==0){
                            this.getCommentData()      //重新获取数据
                            this.comment={};           //清空评论内容
                        }
                    })
                
            },
            handleSelect(key, keyPath) {
                console.log(key, keyPath);
            },
            fetchData(){  //获取活动和发布人的数据
                this.axios.get(`activity/selectByPublicActUser?id=${this.$route.query.actId}`).then(response=>{
                    this.activity = response.data
                    console.log(response.data)

                    if(this.activity.count>=this.activity.maxCount){
                        this.flag = true           // 结束倒计时
                        this.timeEnd = `人数已满`   // 提示
                        this.btnStus=true          // 禁用按钮
                    }
                })
            },
            inroll(val){  //报名

                let username = localStorage.getItem("username");
                this.addActUser.username = username
                this.addActUser.activityId = val
                console.log(this.addActUser)
                this.axios.post(`/activityUser/add`,this.addActUser).then(response=>{
                    if(response.data.code==0){

                            this.selectUser();  //显示是否已参团
                            this.fetchData();   //重新获取数据
                    
                        
                    }else if(response.data.code==1){
                        alert(response.data.message)
                    }
                })
            },

            timeDown(){  //倒计时
              
                const endTime = new Date(this.activity.endTime)
                const nowTime = new Date();
                let leftTime = parseInt((endTime.getTime()-nowTime.getTime())/1000)

                
                let d = parseInt(leftTime/(24*60*60))
                let h = this.formate(parseInt(leftTime/(60*60)%24))
                let m = this.formate(parseInt(leftTime/60%60))
                let s = this.formate(parseInt(leftTime%60))
                if(leftTime <= 0){
                  this.flag = true //结束倒计时
                  this.timeEnd = `已结束` 
                  this.btnStus=true
                  
                }else{
                    this.timeEnd = `${d}天${h}小时${m}分${s}秒`
                }
                
                
            },
            formate (time) {
                if(time>=10){
                  return time
                }else{
                  return `0${time}`
                }
            },
            selectUser(){  //查看是否拼团成功
    
                let username = localStorage.getItem("username");
                this.addActUser.username = username
                this.addActUser.activityId = this.$route.query.actId;

                this.axios.post(`/activityUser/selectUser`,this.addActUser).then(response=>{
                    if(response.data.message=="已参团"){
                        this.btnStus=true;
                        this.tip=response.data.message;
                    }
                })
            }


        },
        mounted(){
            let time = setInterval(()=>{
                if(this.flag==true){
                    clearInterval(time)
                }
                this.timeDown()
            },500);
            


        },
        created(){
            console.log(this.$route.query.actId)
            this.fetchData()
            this.selectUser()
            this.getCommentData()
            this.getCommentCount()
        }

    }
</script>
<style scoped>
        html {
            background: #eee;
        }

        .activityPic{
            width: 300px;
            height: 150px;
            background: url('../../../assets/img/dd.png');
            background-size: cover;
            margin-top: 24px;


        }
        .el-col {
            border-radius: 4px;
        }

        .bg-purple-dark {
            background: #99a9bf;
        }

        .bg-purple {
            background: #d3dce6;
        }

        .bg-purple-light {
            background: #e5e9f2;
        }

        .grid-content {
            border-radius: 4px;
            min-height: 36px;
        }

        .row-bg {
            padding: 10px 0;
            background-color: #f9fafc;
        }

        .time {
            font-size: 13px;
            color: #999;
        }

        .bottom {
            margin-top: 13px;
            line-height: 12px;
        }

        .button {
            padding: 0;
            float: right;
        }

        .image {
            width: 100%;
            display: block;
        }

        .clearfix:before,
        .clearfix:after {
            display: table;
            content: "";
        }

        .clearfix:after {
            clear: both
        }

        .el-card {
            margin: 10px;

        }

        .el-col-offset-2 {
            margin-left: 20px;
        }

.pl{width:90%;border:1px solid #e8e8e8;padding:4px;border-radius:5px;margin-left:8%;position:relative;margin-top:20px}
.tx{position:absolute;top:0px;left:-67px;width:55px;height:50px;background-image:url(../../../assets/img/tx.png);background-repeat:no-repeat;background-position:right 10px;padding-right:12px}
.tx img{width:100%;border-radius:45px}
.pl ul{padding:0px 20px;line-height:26px;margin:unset}
.plbg{background-color:#fafafa;border-bottom:1px dotted #DCDCDC}
.z13{font-size:13px}
.f{float:left}
.jl{color:#ff7800;padding-left:20px;display:none}
.r{float:right}
.dr{clear:right}
.pl .plul{word-wrap:break-word;padding-top:10px;padding-bottom:10px;font-size:14px;background-color:#fafafa}
.hf{float:right;font-size:12px;line-height:26px}
.tx2{width:45px;left:-57px}
    </style>
