<template>
    <div style="background: #eee;padding:10px">
        <el-row style="background: white;height: 500px;overflow-y: scroll;padding:30px 30px 50px 30px;" >
            <el-col>
                <div style="height:30px;margin:20px 0">
                    活动类型：
                    <!-- <el-select v-model="value" placeholder="请选择">
                        <el-option 
                            v-for="item in options" 
                            :key="item.value" 
                            :label="item.label" 
                            :value="item.value"
                        >
                        </el-option>
                    </el-select> -->
                    <el-select v-model="searchMap.categoryId" @change="selCat" placeholder="请选择">
                        <el-option
                          v-for="item in tableCate"
                          :key="item.id"
                          :label="item.categoryName"
                          :value="item.id"
                          
                          >
                        </el-option>
                    </el-select>&nbsp;
                    <el-button type="primary" @click="showAll">显示全部</el-button>
                </div>
            </el-col>
            <el-col style="width: 270px;" v-for="item in activityList">
            <router-link :to="{ path: '/center/detail',query:{actId:item.id}}">
              
                <el-card :body-style="{ padding: '0px' }">
                    <img :src="item.picture" height="228" width="228" class="image">
                    <div style="padding: 14px;">
                        <span>{{item.name}}</span>
                        <div class="bottom clearfix">
                            <div><time class="time">开始时间：{{ item.startTime|formatTime}}</time></div>
                            <div>&nbsp;</div>
                            <div><time class="time">结束时间：{{item.endTime|formatTime}}</time></div>
                            
                            <div>&nbsp;</div>
                            <el-button type="text" class="button"><router-link :to="{ path: '/center/detail',query:{actId:item.id}}">点击报名</router-link></el-button>
                        </div>
                    </div>
                </el-card>

            </router-link>
          
            </el-col>
            <el-col v-if="activityList==''">
                <p style="text-align: center;padding-top: 130px;font-color:#eee;">暂无数据</p>
            </el-col>
            <el-col v-if="activityList!=''">
                <div class="pagination-container" style="text-align: center;">
                    <el-pagination 
                            class="pagiantion"
                            @size-change="fetchData"
                            @current-change="fetchData"
                            :current-page.sync="currentPage"
                            :page-sizes="[10, 20, 30, 40]"
                            :page-size="size"
                            layout="total, sizes, prev, pager, next, jumper"
                            :total="total">
                    </el-pagination>
                </div>
            </el-col>
        
        </el-row>
        
    </div>
</template>
</div>
</body>
<script>
export default {
    data() {
        return {
            activityList:[],
            tableCate:[],
            currentPage: 1,
            total: 10,
            size: 10,
            searchMap: {status:'true'},
            value: '',
        }
    },
    // filters:{
    //     formatDate(val){
    //         return this.moment(val).format("YYYY-MM-DD");
    //     }
    // },
    created(){
        this.fetchCate();
        this.fetchData();
    },
    methods: {
        fetchData (){
                this.axios.post(`/activity/findPage?page=${this.currentPage}&size=${this.size}`,this.searchMap).then(response => {
                    
                    this.activityList = response.data.rows;
                    this.total = response.data.total;
                });
        },
        fetchCate (){
                this.axios.get(`/category/findAll`).then(response => {
                    console.log(response)
                    this.tableCate= response.data;
                   
                });
        },
        handleSelect(key, keyPath) {
            console.log(key, keyPath);
        },
        selCat(){
         
            this.axios.post(`/activity/findPage?page=${this.currentPage}&size=${this.size}`,this.searchMap).then(response => {
                    
                    this.activityList = response.data.rows;
                    this.total = response.data.total;
                });
        },
        showAll(){
            this.searchMap.categoryId=null;
            this.axios.post(`/activity/findPage?page=${this.currentPage}&size=${this.size}`,this.searchMap).then(response => {
                    
                    this.activityList = response.data.rows;
                    this.total = response.data.total;
                });
        }
    }

}
</script>
<style scoped>
html {
    background: #eee;
}
.el-col {
    border-radius: 4px;
}

.bg-purple-dark {
    background: #99a9bf;
}

.bg-purple {
    background: #d3dce6;
}

.bg-purple-light {
    background: #e5e9f2;
}

.grid-content {
    border-radius: 4px;
    min-height: 36px;
}

.row-bg {
    padding: 10px 0;
    background-color: #f9fafc;
}

.time {
    font-size: 13px;
    color: #999;
}

.bottom {
    margin-top: 13px;
    line-height: 12px;
}

.button {
    padding: 0;
    float: right;
}

.image {
    width: 100%;
    display: block;
}

.clearfix:before,
.clearfix:after {
    display: table;
    content: "";
}

.clearfix:after {
    clear: both
}

.el-card {
    margin: 10px;

}

.el-col-offset-2 {
    margin-left: 20px;
}

.el-col-offset-0 {
    margin-left: 30px;
}
</style>

</html>