<template>
	<el-row style="height: 100%">

            <div  style="padding: 20px;background: #eee;height: 100%" >
                <el-col style="height: 100%; " :span="4" >

                    <el-menu style="height: 100%;"
                            default-active="3"
                            class="el-menu-vertical-demo"
                            >
                        <el-menu-item index="1">
                            <i class="el-icon-lx-peoplefill"></i>
                            <span slot="title"><router-link style="color: #303133;" :to="{ path: '/PersonCenter' }">个人中心</router-link></span>
                        </el-menu-item>
                        <el-menu-item index="2">
                            <i class="el-icon-lx-edit"></i>
                            <span slot="title"><router-link style="color: #303133;" :to="{ path: '/Public' }">发布</router-link></span>
                        </el-menu-item>
                        <el-menu-item index="3">
                            <i class="el-icon-setting"></i>
                            <span slot="title"><router-link style="color: #303133;":to="{ path: '/ActivityManager' }">管理</router-link></span>
                        </el-menu-item>
                        <el-menu-item index="4">
                            <i class="el-icon-lx-group"></i>
                            <span slot="title"><router-link style="color: #303133;" :to="{ path: '/Publiced' }">已发布</router-link></span>
                        </el-menu-item>
                        <el-menu-item index="5">
                            <i class="el-icon-lx-roundcheckfill"></i>
                            <span slot="title"><router-link style="color: #303133;" :to="{ path: '/Enroll' }">我已报名</router-link></span>
                        </el-menu-item>
                        
                    </el-menu>

                </el-col>
                <el-col :span="20" style="background: white;padding: 30px 20px;height: 400px;overflow-y: scroll;">

                <el-collapse v-if="show">
                    



                  <el-collapse-item       v-for="(value,key,index) in actUsers" :key="index"   :name="index">
                    <template slot="title">
                     <span>活动名称： {{value[0].activityName}}</span><i class="header-icon el-icon-info"></i>
                    </template>
                         <el-table  :data="value" border style="width: 100%">
                        <el-table-column prop="username" label="用户名" width="100"></el-table-column>
                        <el-table-column prop="sex" label="性别" width="100"></el-table-column>
                        <el-table-column prop="phone" label="手机号码" width="100"></el-table-column>
                        <el-table-column label="头像" prop="" width="100">
                        <template slot-scope="scope"> <img style="width:70px;height:50px;" :src="scope.row.headPic" alt=""> </template>
                        </el-table-column>
                        

                        <el-table-column
                                label="操作"  >
                            <template slot-scope="scope">
                                <el-button @click="view(scope.row.userId,scope.row.userId)"  type="text" >查看</el-button>
                            <!--     <el-button @click="dele(scope.row.userId)"  type="danger" >踢出</el-button> -->
                            </template>
                        </el-table-column>
                    </el-table>
                  </el-collapse-item>

                </el-collapse>
                <div v-if="!show"><el-tag>管理</el-tag><p  style="text-align:center;color:rgba(105, 105, 102, 1);margin-top:100px;">暂无数据</p></div>
                </el-col>
                <div style="clear: both"></div>
            </div>
            <div class="add-form">
                    <!--弹出窗口-->
                    <el-dialog  title="编辑" :visible.sync="formVisible" >
                        <el-form label-width="80px">
                            
                            <el-form-item label="用户名"><div>{{pojo.username}}</div></el-form-item>
                            <el-form-item label="性别"><div>{{pojo.sex}}</div></el-form-item>
                            <el-form-item label="头像"><div><img style="width:100px;height:100px;" :src="pojo.headPic" alt=""></div></el-form-item>
                           
                            <el-form-item label="手机号码"><div>{{pojo.phone}}</div></el-form-item>
                            <el-form-item label="邮件"><div>{{pojo.email}}</div></el-form-item>
                            <el-form-item label="昵称"><div>{{pojo.nickName}}</div></el-form-item>
                            <el-form-item label="等级"><div>{{pojo.userLevel}}</div></el-form-item>
                          
                            
                            <div style="clear: both"></div>
                        </el-form>
                    </el-dialog>
                </div>


    </el-row>
</template>
<script type="text/javascript">
    export default {
  
    data() {
        return {

                actUsers:[],
                show:true,
                formVisible:false,
                pojo:{}

            }
    },
    created() {
        this.fetchData();
    },
    methods:{
            fetchData (){  //获取自己发布的活动以及人数
                let username = localStorage.getItem("username");
                this.axios.get(`/activityUser/getInActUsers?username=${username}`).then(response => {
                    this.actUsers = response.data;
                    console.log(response.data)
                    if(response.data.code==401||response.data.code==402){this.show = false}

                });
            },
            view(val){
                this.axios.get(`/user/findById?userId=${val}`).then(response=>{
                    this.pojo = response.data;
                    this.formVisible = true;
                    console.log(response)
                })
            
            },
            dele(val){

            },
            formatter(row, column){
                return this.moment(row.startTime).format("YYYY-MM-DD")
            },
            formatter1(row, column){
                return this.moment(row.endTime).format("YYYY-MM-DD")
            },
            formatter2(row, column){
                return row.status=="true"?"通过":"未审核";

            }
            
        }
};
</script>
<style type="text/css" scoped>
	.el-menu a{
		display: inline-block;
		width: 100%;
		height: 100%;
	}
</style>