<template>
    <div style="height:500px;overflow:scroll;">
        <el-row style="padding:20px;border: 10px solid #eee;">
            <el-carousel :interval="4000" type="card" height="200px">
                <el-carousel-item v-for="item in BannerList" >
                  <h3><router-link :to="{ path: '/center/detail',query:{actId:item.id}}"><img  :src="item.picture" style="height:200px;width:100%;"   alt=""></router-link></h3>
                </el-carousel-item>
            </el-carousel>
        
        </el-row>
        <el-row style="padding:20px;padding-buttom:10px;">
            <el-row style="border-left: 4px solid #4797f5;padding-left: 10px;margin-bottom:20px;">
                猜你喜欢&nbsp;<span style="font-size:12px;color:red;">(最新)</span>
            </el-row>
            <el-row>
                <el-col :span="5" v-for="(item, index) in activityList" >
                <router-link :to="{ path: '/center/detail',query:{actId:item.id}}">
                <el-card :body-style="{ padding: '0px' }">
                  <img :src="item.picture" style="height:248px;width:100%;" class="image">
                  <div style="padding: 14px;">
                    <span>{{item.name}}</span>
                    <div class="bottom clearfix">
                      <time class="time">发布时间：{{ item.createTime|formatTime }}</time>
                      <el-button type="text" class="button"><router-link :to="{ path: '/center/detail',query:{actId:item.id}}">点击报名</router-link></el-button>
                    </div>
                  </div>
                </el-card>
                </router-link>
              </el-col>
            </el-row>
        </el-row>
       
        
    </div>
</template>
</div>
</body>
<script>
export default {
    data() {
        return {
            activityList:[],
            BannerList:[],
        }
    },
    created(){
        
        this.fetchData();
        this.getBannerList();
    },
    methods: {
        getBannerList(){  //获取banner
            this.axios.get(`/activity/selByOrderCount`).then(response=>{
                this.BannerList = response.data
                console.log(response)
            })
        },
        fetchData (){  //获取最新活动
                this.axios.get(`/activity/selByTime`).then(response => {
                    console.log(response)
                    this.activityList = response.data;
            
                });
        },
      
        handleSelect(key, keyPath) {
            console.log(key, keyPath);
        }
        
    }

}
</script>
<style scoped>
.el-carousel__item h3 {
    color: #475669;
    font-size: 18px;
    opacity: 0.75;
    line-height: 300px;
    margin: 0;
  }
  
  .el-carousel__item:nth-child(2n) {
    background-color: #99a9bf;
  }
  
  .el-carousel__item:nth-child(2n+1) {
    background-color: #d3dce6;
  }
html {
    background: #eee;
}
.el-col {
    border-radius: 4px;
}

.bg-purple-dark {
    background: #99a9bf;
}

.bg-purple {
    background: #d3dce6;
}

.bg-purple-light {
    background: #e5e9f2;
}

.grid-content {
    border-radius: 4px;
    min-height: 36px;
}

.row-bg {
    padding: 10px 0;
    background-color: #f9fafc;
}

.time {
    font-size: 13px;
    color: #999;
}

.bottom {
    margin-top: 13px;
    line-height: 12px;
}

.button {
    padding: 0;
    float: right;
}

.image {
    width: 100%;
    display: block;
}

.clearfix:before,
.clearfix:after {
    display: table;
    content: "";
}

.clearfix:after {
    clear: both
}

.el-card {
    margin: 10px;

}

.el-col-offset-2 {
    margin-left: 20px;
}

/*.el-col-offset-0 {
    margin-left: 30px;
}*/
</style>

</html>