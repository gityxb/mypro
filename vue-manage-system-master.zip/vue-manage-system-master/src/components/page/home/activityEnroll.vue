<template>
	<el-row style="height: 100%">
            <div  style="padding: 20px;background: #eee;height: 100%" >
                <el-col style="height: 100%; " :span="4" >

                    <el-menu style="height: 100%;"
                            default-active="5"
                            class="el-menu-vertical-demo"
                            >
                        <el-menu-item index="1">
                            <i class="el-icon-lx-peoplefill"></i>
                            <span slot="title"><router-link style="color: #303133;" :to="{ path: '/PersonCenter' }">个人中心</router-link></span>
                        </el-menu-item>
                        <el-menu-item index="2">
                            <i class="el-icon-lx-edit"></i>
                            <span slot="title"><router-link style="color: #303133;" :to="{ path: '/Public' }">发布</router-link></span>
                        </el-menu-item>
                        <el-menu-item index="3">
                            <i class="el-icon-setting"></i>
                            <span slot="title"><router-link style="color: #303133;":to="{ path: '/ActivityManager' }">管理</router-link></span>
                        </el-menu-item>
                        <el-menu-item index="4">
                            <i class="el-icon-lx-group"></i>
                            <span slot="title"><router-link style="color: #303133;" :to="{ path: '/Publiced' }">已发布</router-link></span>
                        </el-menu-item>
                        <el-menu-item index="5">
                            <i class="el-icon-lx-roundcheckfill"></i>
                            <span slot="title"><router-link style="color: #303133;" :to="{ path: '/Enroll' }">我已报名</router-link></span>
                        </el-menu-item>
                        
                    </el-menu>

                </el-col>
                <el-col :span="20" style="background: white;padding: 30px 20px;height: 400px;overflow-y: scroll;">
                    
                            <el-table
                                    :data="activityList"
                                    border
                                    style="width: 100%;background: #e9e9e9">
                                <el-table-column
                                        prop="name"
                                        label="活动名"
                                        width="180">
                                </el-table-column>
                                <el-table-column
                                        prop="goTime"
                                        label="出发日期"
                                        :formatter="formatter"
                                        width="180">
                                </el-table-column>
                                
                                <el-table-column
                                        prop="address"
                                        label="地址">
                                </el-table-column>
                                <el-table-column
                                        prop="address"
                                        label="地址">
                                </el-table-column>
                                <el-table-column
                            label="操作"  >
                                <template slot-scope="scope">
                                    <el-button icon="el-icon-view" @click="showDetail(scope.row.id)"  type="text" >查看</el-button>
                                    <el-button  @click="release(scope.row.id)"  type="danger" class="red" >退团</el-button>
                                </template>
                            </el-table-column>
                            </el-table>
                            <div>&nbsp;</div>
                            <span style="color:red;font-size:12px;">tip:仅在活动报名还没结束可退团</span>
                      
                </el-col>
                <div style="clear: both"></div>
            </div>

            <div class="add-form">
                    <!--弹出窗口-->
                    <el-dialog  title="编辑" :visible.sync="formVisible" >
                        <el-form label-width="80px">
                            
                            <el-form-item label="活动名称"><div>{{pojo.name}}</div></el-form-item>
                            <el-form-item label="活动地点"><div>{{pojo.address}}</div></el-form-item>
                            <el-form-item label="当前人数"><div>{{pojo.count}}</div></el-form-item>
                            <el-form-item label="活动图片">
                                <div>
                                    <img style="width:150px;height:100px;" :src="pojo.picture" alt="">
                                </div>
                            </el-form-item>
                            <el-form-item label="活动简介"><div>{{pojo.description}}</div></el-form-item>
                            <el-form-item label="最多人数"><div>{{pojo.maxCount}}</div></el-form-item>
                            <el-form-item label="最少人数"><div>{{pojo.minCount}}</div></el-form-item>
                            <el-form-item label="报名开始"><div>{{pojo.startTime|formatTime}}</div></el-form-item>
                            <el-form-item label="报名结束"><div>{{pojo.endTime|formatTime}}</div></el-form-item>
                            <el-form-item label="联系方式"><div>{{pojo.username}}</div></el-form-item>
                            <el-form-item label="押金"><div>{{pojo.cash}}￥</div></el-form-item>
                            
                            <div style="clear: both"></div>
                        </el-form>
                    </el-dialog>
                </div>


    </el-row>
</template>
<script type="text/javascript">
export default {
  
    data() {
        return {
                activityList: [],
                pojo:{},
                formVisible:false,

            }
    },
    created() {
        this.fetchData();
    },
    methods:{
            fetchData (){  //获取自己参加的活动
                let username = localStorage.getItem("username");
                this.axios.get(`/activity/selectUserActivity?username=${username}`).then(response => {
                    this.activityList = response.data;
                });
            },
            formatter(row, column){
                return this.moment(row.goTime).format("YYYY-MM-DD")
            },
            showDetail (id){
                console.log(this.activityList)
                this.formVisible = true // 打开窗口
                // 调用查询
                this.axios.get(`/activity/findById?id=${id}`).then(response => {
                    this.pojo = response.data;
                    this.formVisible = true;
                    // this.imageUrl=this.pojo.image //显示图片  如页面有图片上传功能放开注释
                })
            },
            release(id){
                let mapOject = {}
                mapOject.username = localStorage.getItem("username")
                mapOject.id = id
                let username = localStorage.getItem("username");
                this.axios.post(`/activityUser/deleteTakeAct`,mapOject).then(response=>{
                    if(response.data.code==0){
                        this.$message.success('退团成功');
                        this.fetchData();
                    }else if((response.data.code==1)){
                        alert(response.data.message)
                    }
                })
               
            }
            
        }
};
</script>
<style type="text/css" scoped>
	.el-menu a{
		display: inline-block;
		width: 100%;
		height: 100%;
	}
</style>