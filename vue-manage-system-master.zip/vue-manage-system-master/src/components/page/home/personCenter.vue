<template>
    <el-row style="height: 100%">
            <div  style="padding: 20px;background: #eee;height: 100%" >
                <el-col style="height: 100%; " :span="4" >

                    <el-menu style="height: 100%;"
                            default-active="1"
                            class="el-menu-vertical-demo"
                            >
                        <el-menu-item index="1">
                            <i class="el-icon-lx-peoplefill"></i>
                            <span slot="title"><router-link style="color: #303133;" :to="{ path: '/PersonCenter' }">个人中心</router-link></span>
                        </el-menu-item>
                        <el-menu-item index="2">
                            <i class="el-icon-lx-edit"></i>
                            <span slot="title"><router-link style="color: #303133;" :to="{ path: '/Public' }">发布</router-link></span>
                        </el-menu-item>
                        <el-menu-item index="3">
                            <i class="el-icon-setting"></i>
                            <span slot="title"><router-link style="color: #303133;":to="{ path: '/ActivityManager' }">管理</router-link></span>
                        </el-menu-item>
                        <el-menu-item index="4">
                            <i class="el-icon-lx-group"></i>
                            <span slot="title"><router-link style="color: #303133;" :to="{ path: '/Publiced' }">已发布</router-link></span>
                        </el-menu-item>
                        <el-menu-item index="5">
                            <i class="el-icon-lx-roundcheckfill"></i>
                            <span slot="title"><router-link style="color: #303133;" :to="{ path: '/Enroll' }">我已报名</router-link></span>
                        </el-menu-item>
                        
                    </el-menu>

                </el-col>


                <el-col  :span="20" style="background: white;padding: 30px 20px;height: 400px;overflow-y: scroll;">
                  <div v-if="show">
                    <el-row>
                        <el-col :span="24">
                            <div class="grid-content">
                                <el-tag>个人中心</el-tag>
                            </div>
                        </el-col>
                    </el-row>

                    <div>&nbsp;</div>
                    <el-row>
                        <el-tabs v-model="first">
                            <el-tab-pane label="基础资料" name="first">
                                <el-col :span="4">
                            <div style="width:150px;">
                                <img style="height:150px;width:150px;border-radius: 150px;" :src="user.headPic" alt="">
                                <div style="text-align:center;font-size:14px;"><a @click="uploadHeadPic" style="color:#337ab7" href="#">修改头像</a></div>
                            </div>
                            
                        </el-col>
                        <el-col :span="16">
                            <div class="userdata">
                                <el-form :model="user"  ref="user"  :rules="rules"  label-width="100px"s class="demo-ruleForm" >

                                    <el-form-item label="用户名" prop="username">
                                        <el-input :disabled="true" v-model="user.username" />  
                                    </el-form-item>

                                    <el-form-item label="手机号码" prop="phone">
                                        <el-input v-model="user.phone"/>  
                                    </el-form-item>
                                    <el-form-item label="邮件" prop="email" >
                                        <el-input v-model="user.email" />  
                                    </el-form-item>

                                    <el-form-item label="性别" prop="sex">
                                    <el-radio-group v-model="user.sex">
                                        <el-radio border label="1">男</el-radio>
                                        <el-radio border label="0">女</el-radio>
                                    </el-radio-group>
                                    </el-form-item>
                                    <el-form-item>
                                        <el-button type="primary" @click="save('user')">立即修改</el-button>
                                        <el-button @click="reSet()">清空</el-button>
                                    </el-form-item>
                                </el-form>
                   
                            </div>
                            
                        </el-col>
                            </el-tab-pane>
                            <el-tab-pane label="修改密码" name="second">
                                <el-form :model="password" ref="password"   class="demo-ruleForm" label-width="80px">
                                    <el-form-item 
                                        label="旧密码" 
                                        prop="pw0"
                                        :rules="[
                                          { required: true, message: '旧密码不能为空'},
                                        
                                        ]"
                                        >
                                        <el-input type="password"   v-model="password.pw0"/>  
                                    </el-form-item>
                                    <el-form-item 
                                        label="新密码" 
                                        prop="pw1"
                                        :rules="[
                                          { required: true, message: '新密码不能为空'},
                                        
                                        ]"
                                        >
                                        <el-input type="password" v-model="password.pw1"/>  
                                    </el-form-item>
                                    <el-form-item 
                                        label="确认密码" 
                                        prop="pw2"
                                        :rules="[
                                          { required: true, message: '再次输入密码'},
                                          
                                        
                                        ]"
                                        >
                                        <el-input type="password" v-model="password.pw2"/>  
                                    </el-form-item>
                                    
                                    
                                    <el-form-item>
                                        <el-button type="primary" @click="savePassword('password')">立即更改</el-button>
                                        <el-button @click="clear()">清空</el-button>
                                    </el-form-item>
                                </el-form>

                            </el-tab-pane>
                          
                        </el-tabs>


                        
                    </el-row>
                        
                </div>
                <div v-if="!show"><el-tag>个人中心</el-tag><p  style="text-align:center;color:rgba(105, 105, 102, 1);margin-top:100px;">暂无数据</p></div>
                </el-col>
                <div style="clear: both"></div>
            </div>
            <div class="add-form">
                    <!--弹出窗口-->
                    <el-dialog
                      title="修改头像"
                      :visible.sync="dialogVisible"
                      width="30%"
                      :before-close="handleClose">
                        <div>
                             <el-upload  class="avatar-uploader" 
                                    action="http://localhost:9102/upload/oss?floder=headPic" 
                                    :show-file-list="false" 
                                    :on-success="handleAvatarSuccess" 
                                    :before-upload="beforeAvatarUpload"
                                    :headers="myHeaders"
                                    >
                                        <img v-if="imageUrl" :src="imageUrl" class="avatar">
                                        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                            </el-upload>
                        </div>
                      

                      <span slot="footer" class="dialog-footer">
                        <el-button @click="dialogVisible = false">取 消</el-button>
                        <el-button type="primary" @click="saveImage">保 存</el-button>
                      </span>
                    </el-dialog>

                </div>


    </el-row>
</template>
<script type="text/javascript">
let token =  localStorage.getItem('token')
    export default {
  
    data() {
        var checkPhone = (rule, value, callback) => {
        if (!value) {
          return callback(new Error('手机号不能为空'));
        } else {
          const reg = /^1[3|4|5|7|8][0-9]\d{8}$/
          console.log(reg.test(value));
          if (reg.test(value)) {
            callback();
          } else {
            return callback(new Error('请输入正确的手机号'));
          }
        }
      };
        return {
                myHeaders: {Authorization: token},
               dialogVisible:false,
               show:true,
               classAct:false,
               first:"first",
               imageUrl:"",
           
               password:{
                   pw1:"",
                   pw2:"",
                   pw0:"",
               },
               user:{
                username:"",
                phone:"",
                email:"",
                sex:"",
               },
               map:{},
               rules: {
                username: [
                        { required: true, message: '请输入活动名称', trigger: 'blur' },
                        { message: '不能为空', trigger: 'blur' }
                    ],
                    phone: [
                        { required: true, message: '请输入手机', trigger: 'blur' },
                        {validator: checkPhone, trigger: 'blur'}
                    ],
                    email: [
                        { required: true, message: '请输入邮件', trigger: 'blur' },
                        { type: 'email', message: '请输入正确的邮箱地址', trigger: 'blur' }
                    ],
                    sex:[
                         { required: true, message: '请选择性别', trigger: 'change' }
                    ]
                },
                

            }
            
    },
  
    created() {
       this.getUserData();
       
    },
    methods:{
        uploadHeadPic(){
            this.dialogVisible = true;
            // this.axios.post(`/upload/`)
        },
           getUserData(){
            let username = localStorage.getItem("username");
            this.axios.get(`/user/selUserByName?username=${username}`).then(response=>{
                if(response.data.code==401||response.data.code==402||response.data.code==1){
                    this.show = false;
                }else{
                    this.user = response.data;
                }
                
            })
           },
           save(form1){

            this.$refs[form1].validate((valid) => {
              if (valid) {
                this.axios.post(`/user/update`,this.user).then(response=>{
                    if(response.data.code==0){
                        this.$message.success('修改成功');
                        this.getUserData();
                    }
                })
              } else {
                console.log('error submit!!');
                return false;
              }
            });


                
           },
           savePassword(form2){
                this.$refs[form2].validate((valid) => {
                if (valid){
                    if(this.password.pw1!=this.password.pw2){ this.$message.error('两次密码不一致'); return false}
                    this.map.oldPassword = this.password.pw0
                    this.map.newPassword = this.password.pw1
                    this.map.username = localStorage.getItem("username");
                    this.axios.post(`/user/updatePassword`,this.map).then(response=>{
                        if(response.data.code==0){
                            this.$message.success('修改成功');
                            this.$router.push({path:'login'});
                            this.getUserData();
                        }else if(response.data.code==1){
                            alert(response.data.message)
                        }
                    })
                } else {
                    return false;
                }
            });
                
                
           },
           reSet(){
            this.user.username=""
            this.user.phone=""
            this.user.email=""
            
           },
           clear(){
            this.password.pw0=""
            this.password.pw1=""
            this.password.pw2=""
           },
           //****图片上传相关代码  如页面有图片上传功能放开注释 ****
            handleAvatarSuccess(res, file) {
                alert("上传成功")
                console.log(file)
                this.imageUrl = file.response;

                console.log(file.response)
            },
            beforeAvatarUpload(file) {
                // const isJPG = file.type === 'image/jpg';
                // const isLt2M = file.size / 1024 / 1024 < 2;
                //
                // if (!isJPG) {
                //     this.$message.error('上传头像图片只能是 JPG 格式!');
                // }
                // if (!isLt2M) {
                //     this.$message.error('上传头像图片大小不能超过 2MB!');
                // }
                // return isJPG && isLt2M;
            },
            handleClose(done) {
                this.$confirm('确认关闭？')
                  .then(_ => {
                    done();
                  })
                  .catch(_ => {});
            },
            saveImage(){
                this.user.headPic=this.imageUrl
                this.user.username=localStorage.getItem("username")
                console.log(this.pojo)
                this.axios.post(`/user/update`,this.user).then(response=>{
                    if(response.data.code==0){
 
                        this.dialogVisible = false;
                    }
                })
            }

        }
};
</script>
<style type="text/css" scoped>
.el-menu a{
        display: inline-block;
        width: 100%;
        height: 100%;
    }
    
.pl{width:90%;border:1px solid #e8e8e8;padding:4px;border-radius:5px;margin-left:8%;position:relative;margin-top:20px}
.tx{position:absolute;top:0px;left:-67px;width:55px;height:50px;background-image:url(../../../assets/img/tx.png);background-repeat:no-repeat;background-position:right 10px;padding-right:12px}
.tx img{width:100%;border-radius:45px}
.pl ul{padding:0px 20px;line-height:26px;margin:unset}
.plbg{background-color:#fafafa;border-bottom:1px dotted #DCDCDC}
.z13{font-size:13px}
.f{float:left}
.jl{color:#ff7800;padding-left:20px;display:none}
.r{float:right}
.dr{clear:right}
.pl .plul{word-wrap:break-word;padding-top:10px;padding-bottom:10px;font-size:14px;background-color:#fafafa}
.hf{float:right;font-size:12px;line-height:26px}
.tx2{width:45px;left:-57px}
.userdata p{
    font-size: 16px;
    padding-bottom: 14px;
}
.avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
</style>

  
