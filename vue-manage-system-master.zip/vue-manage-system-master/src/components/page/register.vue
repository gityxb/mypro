<template>
    <div class="login-wrap">
        
        <div style="height:100px;width:700px;margin:0 auto;">
            <div style="padding-top:50px;">
                <div style="text-align:center;color:#7b7b7b;font-size: 20px;">用户注册</div>
                <div class="container">
            <div class="form-box">
                <div style="width:600px;margin:0 auto;">
                <!-- <el-form  ref="form" :model="form" label-width="80px">
                    <el-form-item label="用户名">
                        <el-input v-model="form.name"></el-input>
                    </el-form-item>
                    <el-form-item label="手机号码">
                        <el-input v-model="form.name"></el-input>
                    </el-form-item>
                    <el-form-item label="选择器">
                        <el-select v-model="form.region" placeholder="请选择">
                            <el-option key="bbk" label="步步高" value="bbk"></el-option>
                            <el-option key="xtc" label="小天才" value="xtc"></el-option>
                            <el-option key="imoo" label="imoo" value="imoo"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="日期时间">
                        <el-col :span="11">
                            <el-date-picker
                                type="date"
                                placeholder="选择日期"
                                v-model="form.date1"
                                value-format="yyyy-MM-dd"
                                style="width: 100%;"
                            ></el-date-picker>
                        </el-col>
                        <el-col class="line" :span="2">-</el-col>
                        <el-col :span="11">
                            <el-time-picker
                                placeholder="选择时间"
                                v-model="form.date2"
                                style="width: 100%;"
                            ></el-time-picker>
                        </el-col>
                    </el-form-item>
                    <el-form-item label="城市级联">
                        <el-cascader :options="options" v-model="form.options"></el-cascader>
                    </el-form-item>
                    <el-form-item label="选择开关">
                        <el-switch v-model="form.delivery"></el-switch>
                    </el-form-item>
                    <el-form-item label="多选框">
                        <el-checkbox-group v-model="form.type">
                            <el-checkbox label="步步高" name="type"></el-checkbox>
                            <el-checkbox label="小天才" name="type"></el-checkbox>
                            <el-checkbox label="imoo" name="type"></el-checkbox>
                        </el-checkbox-group>
                    </el-form-item>
                    <el-form-item label="单选框">
                        <el-radio-group v-model="form.resource">
                            <el-radio label="步步高"></el-radio>
                            <el-radio label="小天才"></el-radio>
                            <el-radio label="imoo"></el-radio>
                        </el-radio-group>
                    </el-form-item>
                    <el-form-item label="文本框">
                        <el-input type="textarea" rows="5" v-model="form.desc"></el-input>
                    </el-form-item>
                    <el-form-item>
                        <el-button type="primary" @click="onSubmit">表单提交</el-button>
                        <el-button>取消</el-button>
                    </el-form-item>
                </el-form> -->
                            <el-form label-width="80px" :model="pojo" :rules="rules" ref="pojo">
                                <el-form-item label="用户名" prop="username">
                                    <el-input size="small" label-width="50" v-model="pojo.username"></el-input>
                                </el-form-item>
                                <el-form-item label="手机号码" prop="phone">
                                    <el-input size="small" v-model="pojo.phone"></el-input>
                                </el-form-item>
                                <el-form-item label="邮箱" prop="email">
                                    <el-input size="small" v-model="pojo.email"></el-input>
                                </el-form-item>
                                <el-form-item label="昵称" prop="nickName">
                                    <el-input size="small" v-model="pojo.nickName"></el-input>
                                </el-form-item>
                                <el-form-item label="性别" prop="sex">
                                    <el-radio-group v-model="pojo.sex" size="medium">
                                        <el-radio border label="1">男</el-radio>
                                        <el-radio border label="0">女</el-radio>
                                    </el-radio-group>
                                </el-form-item>

                                <el-form-item label="密码" prop="password">
                                <el-input type="password" v-model="pojo.password" auto-complete="off"></el-input>
                              </el-form-item>
                              <el-form-item label="确认密码" prop="checkPass">
                                <el-input type="password" v-model="pojo.checkPass" auto-complete="off"></el-input>
                              </el-form-item>
                                <el-form-item>
                                    <el-button type="primary" @click="onSubmit('pojo')">立即注册</el-button>
                                    <el-button>取消</el-button>
                                </el-form-item>
                                <el-button style="float:right;" type="text" @click="returnLogin">返回登录</el-button>
                                <div style="clear:both"></div>
                            </el-form>
                </div>
            </div>
        </div>
            </div>
        </div>
         
        
    </div>
</template>

<script>
export default {

     
    data() {
        var checkPhone = (rule, value, callback) => {
        if (!value) {
          return callback(new Error('手机号不能为空'));
        } else {
          const reg = /^1[3|4|5|7|8][0-9]\d{8}$/
          console.log(reg.test(value));
          if (reg.test(value)) {
            callback();
          } else {
            return callback(new Error('请输入正确的手机号'));
          }
        }
      };
        var validatePass = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入密码'));
        } else {
          if (this.pojo.checkPass !== '') {
            this.$refs.pojo.validateField('checkPass');
          }
          callback();
        }
      };
      var validatePass2 = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请再次输入密码'));
        } else if (value !== this.pojo.password) {
          callback(new Error('两次输入密码不一致!'));
        } else {
          callback();
        }
      };
        return {
            pojo:{
                password: '',
                checkPass: '',
            },
            rules:{
                username: [
                    { required: true, message: '填写用户名', trigger: 'blur' }
                ],
                phone: [
                        { required: true, message: '请输入手机', trigger: 'blur' },
                        {validator: checkPhone, trigger: 'blur'}
                ],
                email: [
                        { required: true, message: '请输入邮件', trigger: 'blur' },
                        { type: 'email', message: '请输入正确的邮箱地址', trigger: 'blur' }
                ],
                nickName: [
                    { required: true, message: '请填写昵称', trigger: 'blur' }
                ],
                sex:[
                    { required: true, message: '请选择性别', trigger: 'change' }
                ],
                password: [
                    { validator: validatePass, trigger: 'blur' }
                ],
                checkPass: [
                    { validator: validatePass2, trigger: 'blur' }
                ],

            }
            
            
        };
    },
    methods: {
        returnLogin(){
            this.$router.push('/login');
        },
        onSubmit(form) {

            this.$refs[form].validate((valid) => {
              if (valid) {
                this.axios.post(`/login/register`, this.pojo).then(response=>{
                    if(response.data.code==0){
                      
                        this.$message.success('注册成功');
                        this.$router.push('/login');
                    }else if(response.data.code==403){
                        alert(response.data.message)
                    }
                })
              } else {
                return false;
              }
            });

            
            
        }
    }
};
</script>
<style type="text/css" scoped>
    .login-wrap{
        position: relative;
        width: 100%;
        height: 100%;
        background-image: url(../../assets/img/login-bg.jpg);
        background-size:cover;
    }
    .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 100px;
    height: 100px;
    line-height: 100px;
    text-align: center;
  }
  .avatar {
    width: 100px;
    height: 100px;
    display: block;
  }
</style>