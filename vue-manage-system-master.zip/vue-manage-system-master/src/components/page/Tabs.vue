<template>
    <div class="">
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item><i class="el-icon-lx-copy"></i> 前台留言</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="container">
            <el-tabs v-model="message">
                <el-tab-pane :label="`未读消息(${unread.length})`" name="first">
                    <el-table :data="unread" :show-header="false" style="width: 100%">
                        <el-table-column>
                            <template slot-scope="scope">
                                <span class="message-title" @click="showDetail(scope.row.id)">{{scope.row.title}}--{{scope.row.username}}</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="date" :formatter="formatter" width="180"></el-table-column>
                        <el-table-column width="120">
                            <template slot-scope="scope">
                                <el-button size="small" @click="handleRead(scope.row.id)">标为已读</el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                 
                </el-tab-pane>
                <el-tab-pane :label="`已读消息(${read.length})`" name="second">
                    <template v-if="message === 'second'">
                        <el-table :data="read" :show-header="false" style="width: 100%">
                            <el-table-column>
                                <template slot-scope="scope">
                                    <span class="message-title" @click="showDetail(scope.row.id)">{{scope.row.title}}--{{scope.row.username}}</span>
                                </template>
                            </el-table-column>
                            <el-table-column prop="date" :formatter="formatter" width="150"></el-table-column>
                            <el-table-column width="120">
                                <template slot-scope="scope">
                                    <el-button type="danger" @click="handleDel(scope.row.id)">删除</el-button>
                                </template>
                            </el-table-column>
                        </el-table>
                       <!--  <div class="handle-row">
                            <el-button @click="delAll" type="danger">删除全部</el-button>
                        </div> -->
                    </template>
                </el-tab-pane>
                <div class="add-form">
                    <!--弹出窗口-->
                    <el-dialog  title="编辑" :visible.sync="formVisible" >
                        <el-form label-width="80px">
                            
                            <el-form-item label="题目:"><div>{{pojo.title}}</div></el-form-item>
                            <el-form-item label="内容:"><div v-html="pojo.message">{{pojo.message}}</div></el-form-item>
                            <el-form-item label="提交人:"><div >{{pojo.username}}</div></el-form-item>
                          
                            
                            <div style="clear: both"></div>
                        </el-form>
                    </el-dialog>
                </div>
              <!--   <el-tab-pane :label="`回收站(${recycle.length})`" name="third">
                    <template v-if="message === 'third'">
                        <el-table :data="recycle" :show-header="false" style="width: 100%">
                            <el-table-column>
                                <template slot-scope="scope">
                                    <span class="message-title">{{scope.row.title}}</span>
                                </template>
                            </el-table-column>
                            <el-table-column prop="date" width="150"></el-table-column>
                            <el-table-column width="120">
                                <template slot-scope="scope">
                                    <el-button @click="handleRestore(scope.$index)">还原</el-button>
                                </template>
                            </el-table-column>
                        </el-table>
                        <div class="handle-row">
                            <el-button type="danger">清空回收站</el-button>
                        </div>
                    </template>
                </el-tab-pane> -->
            </el-tabs>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'tabs',
        data() {
            return {
                message: 'first',
                showHeader: false,
                unread: [],
                read: [],
                formVisible:false,
                pojo:{},
             
            }
        },
        created(){
            this.getHandleUnRead();
            this.getHandleRead();
        },
        methods: {
            getHandleUnRead(index) {
                this.axios.get(`/message/findUnRead`).then(response=>{
                    this.unread = response.data;
                    // console.log(response);
                    // console.log(this.unread)
                })
                // const item = this.unread.splice(index, 1);
                // console.log(item);
                // this.read = item.concat(this.read);
            },
            getHandleRead(index) {
                this.axios.get(`/message/findRead`).then(response=>{
                    this.read = response.data;
                  
                    console.log(this.read)
                })
                // const item = this.read.splice(index, 1);
                // this.recycle = item.concat(this.recycle);
            },
            handleRead(id){
               alert(id)
                this.axios.post(`/message/setStuts?id=${id}`).then(response=>{
                    if(response.data.code==0){
                        this.getHandleUnRead();
                        this.getHandleRead();
                    }
                    console.log(response)
                })
            },
            handleDel(id){
                this.axios.get(`/message/delete?id=${id}`).then(response=>{
                    if(response.data.code==0){
                        alert(response.data.message)
                        this.getHandleRead();
                    }
                    console.log(response)
                })
             
            },
            handleRestore(index) {
                // const item = this.recycle.splice(index, 1);
                // this.read = item.concat(this.read);
            },
            formatter(row, column){
                return this.moment(row.startTime).format("YYYY-MM-DD")
            },
            showDetail(val){
                this.axios.get(`/message/findById?id=${val}`).then(response=>{

                    this.pojo = response.data
                    this.formVisible = true;
                    console.log(response);
                })
            }
        },
        computed: {
            unreadNum(){
                return this.unread.length;
            }
        }
    }

</script>

<style>
.message-title{
    cursor: pointer;
}
.handle-row{
    margin-top: 30px;
}
</style>

