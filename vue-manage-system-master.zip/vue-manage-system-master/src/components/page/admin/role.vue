<template>
    <div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item>
                    <i class="el-icon-lx-cascades"></i> 角色管理
                </el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="container">
            <div class="app-container">
            <div class="box">
                <div class="filter-container">
                    <!--查询表单-->
                    <el-form :inline="true" >
                        <el-form-item label="角色名称">
                            <el-input v-model="searchMap.rname" placeholder="角色名称" class="filter-item" ></el-input></el-form-item>
                        <el-form-item label="权限">
                            <el-input v-model="searchMap.power" placeholder="权限" class="filter-item" ></el-input></el-form-item>

                        <el-button class="dalfBut" @click="fetchData()">查询</el-button>
                        <el-button type="primary"  class="butT" @click="formVisible=true;pojo={}">新增</el-button>
                    </el-form>
                </div>

                <el-table :data="tableData" border style="width: 100%">
                    <el-table-column prop="id" label="id" width="80"></el-table-column>
                    <el-table-column prop="rname" label="角色名称" width="80"></el-table-column>
                    <el-table-column prop="power" label="权限" width="80"></el-table-column>

                    <el-table-column
                            label="操作">
                        <template slot-scope="scope">
                            <el-button icon="el-icon-edit" @click="edit(scope.row.id)"  type="text" >编辑</el-button>
                            <el-button icon="el-icon-delete" class="red" @click="dele(scope.row.id)"  type="text" >删除</el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <div class="pagination-container">
                    <el-pagination
                            class="pagiantion"
                            @size-change="fetchData"
                            @current-change="fetchData"
                            :current-page.sync="currentPage"
                            :page-sizes="[10, 20, 30, 40]"
                            :page-size="size"
                            layout="total, sizes, prev, pager, next, jumper"
                            :total="total">
                    </el-pagination>
                </div>
                <div class="add-form">
                    <!--弹出窗口-->
                    <el-dialog  title="编辑" :visible.sync="formVisible" >
                        <el-form :model="pojo" :rules="rules" ref="pojo" label-width="80px">
                            <el-form-item label="角色名称" prop="rname">
                                <el-input v-model="pojo.rname"></el-input></el-form-item>
                            <el-form-item label="权限" prop="power">
                                <!-- <el-input v-model="pojo.power"></el-input> -->
                                <el-input-number v-model="pojo.power"   :min="1" :max="10"></el-input-number>
                            </el-form-item>


                            <el-form-item>
                                <el-button type="primary" @click="save('pojo')">保存</el-button>
                                <el-button @click="formVisible = false" >关闭</el-button>
                            </el-form-item>
                            <div style="clear:both"></div>
                        </el-form>
                    </el-dialog>
                </div>

            </div>
        </div>
            
        </div>

    </div>
</template>
<script>
export default {
    name: 'basetable',
    data() {
        return {
                tableData: [],
                currentPage: 1,
                total: 10,
                size: 10,
                searchMap: {},
                pojo: {},
                formVisible: false,
                imageUrl: '',
                rules:{
                    rname: [
                        { required: true, message: '填写角色名', trigger: 'blur' }
                    ],
                    power:[
                        { required: true, message: '填写权限值', trigger: 'change' }
                    ]
                

                }

            }
    },
    created() {
        this.fetchData();
    },
    methods:{
            fetchData (){
                this.axios.post(`/role/findPage?page=${this.currentPage}&size=${this.size}`,this.searchMap).then(response => {
                    this.tableData = response.data.rows;
                    this.total = response.data.total;
                });
            },
            save (form){

              this.$refs[form].validate((valid) => {
              if (valid) {
                    this.axios.post(`/role/${this.pojo.id==null?'add':'update'}`,this.pojo).then(response => {
                    this.fetchData (); //刷新列表
                    this.formVisible = false ;//关闭窗口
                });
              } else {
                return false;
              }
            });
                
            },
            edit (id){
                this.formVisible = true // 打开窗口
                // 调用查询,数据回显
                this.axios.get(`/role/findById?id=${id}`).then(response => {
                    this.pojo = response.data;
                    console.log(id);
                    // this.imageUrl=this.pojo.image //显示图片  如页面有图片上传功能放开注释
                })
            },
            dele (id){
                this.$confirm('确定要删除此记录吗?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then( () => {
                    this.axios.get(`/role/delete?id=${id}`).then(response => {
                        this.fetchData (); //刷新列表
                    })
                })
            },

        }
};
</script>
<style scoped>
.handle-box {
    margin-bottom: 20px;
}

.handle-select {
    width: 120px;
}

.handle-input {
    width: 300px;
    display: inline-block;
}

.table {
    width: 100%;
    font-size: 14px;
}

.red {
    color: #ff0000;
}

.mr10 {
    margin-right: 10px;
}

.table-td-thumb {
    display: block;
    margin: auto;
    width: 40px;
    height: 40px;
}

.avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
}

.avatar-uploader .el-upload:hover {
    border-color: #409EFF;
}

.el-upload--text {
    width: 100px;
    height: 100px;
}

.avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 100px;
    height: 100px;
    line-height: 100px;
    text-align: center;
}

.avatar {
    width: 100px;
    height: 100px;
    display: block;
}
</style>