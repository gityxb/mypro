<template>
    <div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item>
                    <i class="el-icon-lx-cascades"></i> 角色管理
                </el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="container">
            <div class="app-container">
            <div class="box">
                <div class="filter-container">
                    <!--查询表单-->
                    <el-form :inline="true" >
                        

                        <el-form-item label="活动名称">
                            <el-input v-model="searchMap.name" placeholder="活动名称" class="filter-item" ></el-input>
                        </el-form-item>

                        

                        <el-button class="dalfBut" @click="fetchData()">查询</el-button>
                        <!-- <el-button type="primary"  class="butT" @click="formVisible=true;pojo={}">新增</el-button> -->
                    </el-form>
                </div>

                <el-table :data="tableData" border style="width: 100%">
                    <el-table-column prop="id" label="活动id" width="80"></el-table-column>
                    <!-- <el-table-column prop="categoryId" label="活动类型" width="80"></el-table-column> -->
                    
                    <el-table-column prop="name" label="活动名称" width="80"></el-table-column>
                    <el-table-column prop="address" label="活动地点" :formatter="formatter2" width="80"></el-table-column>
                    <el-table-column label="封面" prop="" width="90">
                    <template slot-scope="scope"> <img style="width:70px;height:50px;" :src="scope.row.picture" alt=""> </template>
                    </el-table-column>
                    <el-table-column prop="count" label="当前人数/人" width="85"></el-table-column>
                    <el-table-column prop="maxCount" label="最多人数/人" width="85"></el-table-column>
                    <el-table-column prop="minCount" label="最少人数/人" width="85"></el-table-column>
                    <el-table-column prop="startTime" label="开始报名" :formatter="formatter" width="85"></el-table-column>
                    <el-table-column prop="endTime" label="结束报名" :formatter="formatter1" width="85"></el-table-column>
                    <el-table-column prop="username" label="联系方式" width="80"></el-table-column>
                    <!-- <el-table-column prop="status" label="审核状态" width="70"></el-table-column> -->

                    <el-table-column label="审核状态">
                        <template slot-scope="scope">
                            <div>
                                <el-switch
                                  v-model="scope.row.status"
                                  active-color="#13ce66"
                                  inactive-color="#ff4949"
                                  inactive-value="false"
                                  active-value="true"
                                  @change="changStus(scope.row)"
                                  >
                                </el-switch>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column prop="cash" label="押金/￥" width="70"></el-table-column>
                    <el-table-column prop="description" :formatter="formatter2" label="活动简介" width="80"></el-table-column>
                    <el-table-column
                            label="操作"  >
                        <template slot-scope="scope">
                            <el-button icon="el-icon-view" @click="edit(scope.row.id)"  type="text" >查看</el-button>
                            <el-button icon="el-icon-delete" @click="dele(scope.row.id)"  type="text" class="red" >删除</el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <div class="pagination-container">
                    <el-pagination
                            class="pagiantion"
                            @size-change="fetchData"
                            @current-change="fetchData"
                            :current-page.sync="currentPage"
                            :page-sizes="[10, 20, 30, 40]"
                            :page-size="size"
                            layout="total, sizes, prev, pager, next, jumper"
                            :total="total">
                    </el-pagination>
                </div>
                <div class="add-form">
                    <!--弹出窗口-->
                    <el-dialog  title="活动详情" :visible.sync="formVisible" >
                        <el-form label-width="80px">
                            <el-form-item label="活动类型"><div>{{pojo.categoryId}}</div></el-form-item>
                            <el-form-item label="活动简介"><div>{{pojo.description}}</div></el-form-item>
                            <el-form-item label="活动名称"><div>{{pojo.name}}</div></el-form-item>
                            <el-form-item label="活动图片">
                                <div>
                                    <img style="width:150px;height:100px;" :src="pojo.picture" alt="">
                                </div>
                            </el-form-item>
                            <el-form-item label="活动地点"><div>{{pojo.address}}</div></el-form-item>
                            <el-form-item label="当前人数"><div>{{pojo.count}}</div></el-form-item>
                            <el-form-item label="最多人数"><div>{{pojo.maxCount}}</div></el-form-item>
                            <el-form-item label="最少人数"><div>{{pojo.minCount}}</div></el-form-item>
                            <el-form-item label="报名开始"><div>{{pojo.startTime}}</div></el-form-item>
                            <el-form-item label="报名结束"><div>{{pojo.endTime}}</div></el-form-item>
                            <el-form-item label="联系方式"><div>{{pojo.username}}</div></el-form-item>
                            <el-form-item label="审核状态"><div>{{pojo.status}}</div></el-form-item>
                          
                            <el-form-item label="押金"><div>{{pojo.cash}}</div></el-form-item>
<!-- 
                            <el-form-item label="活动简介"><el-input v-model="pojo.description"></el-input></el-form-item>
                            <el-form-item label="活动名称"><el-input v-model="pojo.name"></el-input></el-form-item>
                            <el-form-item label="活动地点"><el-input v-model="pojo.address"></el-input></el-form-item>
                            <el-form-item label="当前人数"><el-input v-model="pojo.count"></el-input></el-form-item> -->
                            <!-- <el-form-item label="最多人数限制"><el-input v-model="pojo.maxCount"></el-input></el-form-item>
                            <el-form-item label="最少人数"><el-input v-model="pojo.minCount"></el-input></el-form-item>
                            <el-form-item label="报名开始时间"><el-input v-model="pojo.startTime"></el-input></el-form-item>
                            <el-form-item label="结束时间"><el-input v-model="pojo.endTime"></el-input></el-form-item>
                            <el-form-item label="联系方式"><el-input v-model="pojo.username"></el-input></el-form-item>
                            <el-form-item label="审核状态"><el-input v-model="pojo.status"></el-input></el-form-item> -->
                          <!--   <el-form-item label="押金"><el-input v-model="pojo.cash"></el-input></el-form-item> -->

                            <!-- 图片上传代码 如页面有图片上传功能放开注释 ****
                            <el-form-item label="图片">
                                <el-upload
                                        class="avatar-uploader"
                                        action="/upload/native"
                                        :show-file-list="false"
                                        :on-success="handleAvatarSuccess"
                                        :before-upload="beforeAvatarUpload">
                                    <img v-if="imageUrl" :src="imageUrl" class="avatar">
                                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                                </el-upload>
                            </el-form-item>
                            -->

                            <!-- <el-form-item>
                                <el-button type="primary" @click="save()">保存</el-button>
                                <el-button @click="formVisible = false" >关闭</el-button>
                            </el-form-item> -->
                            <div style="clear: both"></div>
                        </el-form>
                    </el-dialog>
                </div>

            </div>
        </div>
            
        </div>

    </div>
</template>
<script>
export default {
    name: 'basetable',
    data() {
        return {
                tableData: [],
                currentPage: 1,
                total: 10,
                size: 10,
                searchMap: {},
                pojo: {},
                formVisible: false,
                imageUrl: '',
              
                value2: true

            }
    },
    created() {
        this.fetchData();
    },
    methods:{
            fetchData (){
                this.axios.post(`/activity/findPage?page=${this.currentPage}&size=${this.size}`,this.searchMap).then(response => {
                    console.log(response)  
                    this.tableData = response.data.rows;
                    this.total = response.data.total;
                });
            },
            save (){
                // this.pojo.image= this.imageUrl; //如页面有图片上传功能放开注释
                this.axios.post(`/activity/${this.pojo.id==null?'add':'update'}`,this.pojo).then(response => {
                    this.fetchData (); //刷新列表
                    this.formVisible = false ;//关闭窗口
                });
            },
            edit (id){
                this.formVisible = true // 打开窗口
                // 调用查询
                this.axios.get(`/activity/findById?id=${id}`).then(response => {
                    this.pojo = response.data;
                    // this.imageUrl=this.pojo.image //显示图片  如页面有图片上传功能放开注释
                })
            },
            dele (id){
                this.$confirm('确定要删除此记录吗?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then( () => {
                    this.axios.get(`/activity/delete?id=${id}`).then(response => {
                        if(response.data.code==0){
                            this.$message({
                              message: '删除成功',
                              type: 'success'
                            });
                            this.fetchData ();//刷新列表
                        }else{
                            this.$message.error(response.data.message);
                        }
                    })
                })
            },
            formatter(row, column){
                return this.moment(row.startTime).format("YYYY-MM-DD")
            },
            formatter1(row, column){
                return this.moment(row.endTime).format("YYYY-MM-DD")
            },
            formatter2(row, column){
                return row.description.length>5?row.description.substring(0, 6)+"...":row.description;
            },
            changStus(val){
                // console.log(val)
                this.axios.post(`/activity/updataStus`,val,).then(response=>{
                    if(response.data.code==0){
                        this.$message.success('更新成功');
                        this.fetchData();
                        console.log(response)
                    }else{
                        this.$message.error('更新失败');
                        console.log(response)
                    }
                })
               
            }
            /* ****图片上传相关代码  如页面有图片上传功能放开注释 ****
            handleAvatarSuccess(res, file) {
                this.imageUrl = file.response;
            },
            beforeAvatarUpload(file) {
                const isJPG = file.type === 'image/jpeg';
                const isLt2M = file.size / 1024 / 1024 < 2;

                if (!isJPG) {
                    this.$message.error('上传头像图片只能是 JPG 格式!');
                }
                if (!isLt2M) {
                    this.$message.error('上传头像图片大小不能超过 2MB!');
                }
                return isJPG && isLt2M;
            }*/
        }
};
</script>
<style scoped>
.handle-box {
    margin-bottom: 20px;
}

.handle-select {
    width: 120px;
}

.handle-input {
    width: 300px;
    display: inline-block;
}

.table {
    width: 100%;
    font-size: 14px;
}

.red {
    color: #ff0000;
}

.mr10 {
    margin-right: 10px;
}

.table-td-thumb {
    display: block;
    margin: auto;
    width: 40px;
    height: 40px;
}

.avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
}

.avatar-uploader .el-upload:hover {
    border-color: #409EFF;
}

.el-upload--text {
    width: 100px;
    height: 100px;
}

.avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 100px;
    height: 100px;
    line-height: 100px;
    text-align: center;
}

.avatar {
    width: 100px;
    height: 100px;
    display: block;
}
</style>