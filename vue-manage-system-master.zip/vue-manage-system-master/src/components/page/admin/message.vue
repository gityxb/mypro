<template>
    <div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item>
                    <i class="el-icon-lx-cascades"></i>评论管理
                </el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="container">
        <div class="app-container">
            <div class="box">
                <div class="filter-container">
                    <!--查询表单-->
                    <el-form :inline="true" >
                        <!-- <el-form-item label="user_id">
                            <el-input v-model="searchMap.userId" placeholder="user_id" class="filter-item" ></el-input></el-form-item> -->
                        <el-form-item label="消息">
                            <el-input v-model="searchMap.message" placeholder="留言" class="filter-item" ></el-input></el-form-item>

                        <el-button class="dalfBut" @click="fetchData()">查询</el-button>
                        <!-- <el-button type="primary"  class="butT" @click="formVisible=true;pojo={}">新增</el-button> -->
                    </el-form>
                </div>

                <el-table :data="tableData" border style="width: 100%">
                    <el-table-column prop="id" label="id" width="80"></el-table-column>
                    <!-- <el-table-column prop="userId" label="user_id" width="80"></el-table-column> -->
                    <el-table-column prop="comment" label="评论内容" width="250"></el-table-column>
                    <el-table-column  prop="username" label="用户" width="80"></el-table-column>
                    <el-table-column prop="createTime" :formatter="formatTimeh" label="评论时间" width="160"></el-table-column>

                    <el-table-column
                            label="操作"  >
                        <template slot-scope="scope">
                            <el-button icon="el-icon-view" @click="edit(scope.row.id)" type="text" >查看</el-button>
                            <el-button icon="el-icon-delete" @click="dele(scope.row.id)" class="red" type="text" >删除
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <div class="pagination-container">
                    <el-pagination
                            class="pagiantion"
                            @size-change="fetchData"
                            @current-change="fetchData"
                            :current-page.sync="currentPage"
                            :page-sizes="[10, 20, 30, 40]"
                            :page-size="size"
                            layout="total, sizes, prev, pager, next, jumper"
                            :total="total">
                    </el-pagination>
                </div>
                <div class="add-form">
                    <!--弹出窗口-->
                    <el-dialog  title="查看" :visible.sync="formVisible" >
                        <el-form label-width="80px">
                            <el-form-item label="评论人：" >{{pojo.username}}</el-form-item>
                            <el-form-item label="内容：" >{{pojo.comment}}</el-form-item>
                            <el-form-item label="时间：" >{{pojo.createTime|formatTimeh}}</el-form-item>
                            <!-- 图片上传代码 如页面有图片上传功能放开注释 ****
                            <el-form-item label="图片">
                                <el-upload
                                        class="avatar-uploader"
                                        action="/upload/native"
                                        :show-file-list="false"
                                        :on-success="handleAvatarSuccess"
                                        :before-upload="beforeAvatarUpload">
                                    <img v-if="imageUrl" :src="imageUrl" class="avatar">
                                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                                </el-upload>
                            </el-form-item>
                            -->

                            <el-form-item>
                                <el-button type="primary" @click="save()">保存</el-button>
                                <el-button @click="formVisible = false" >关闭</el-button>
                            </el-form-item>
                            <div style="clear:both"></div>
                        </el-form>
                    </el-dialog>
                </div>

            </div>
        </div>
            
        </div>

    </div>
</template>
<script>
export default {
    name: 'basetable',
    data() {
        return {
                tableData: [],
                currentPage: 1,
                total: 10,
                size: 10,
                searchMap: {},
                pojo: {},
                formVisible: false,
                imageUrl: ''

            }
    },
    created() {
        this.fetchData();
    },
    methods:{
            fetchData (){
                this.axios.post(`/comment/findPage?page=${this.currentPage}&size=${this.size}`,this.searchMap).then(response => {
                    this.tableData = response.data.rows;
                    this.total = response.data.total;
                });
            },
            save (){
                // this.pojo.image= this.imageUrl; //如页面有图片上传功能放开注释
                this.axios.post(`/comment/${this.pojo.id==null?'add':'update'}`,this.pojo).then(response => {
                    this.fetchData (); //刷新列表
                    this.formVisible = false ;//关闭窗口
                });
            },
            edit (id){
                this.formVisible = true // 打开窗口
                // 调用查询
                this.axios.get(`/comment/findById?id=${id}`).then(response => {
                    this.pojo = response.data;
                    // this.imageUrl=this.pojo.image //显示图片  如页面有图片上传功能放开注释
                })
            },
            dele (id){
                this.$confirm('确定要删除此记录吗?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then( () => {
                    this.axios.get(`/comment/delete?id=${id}`).then(response => {
                        if(response.data.code==0){
                            this.$message({
                              message: '删除成功',
                              type: 'success'
                            });
                            this.fetchData ();//刷新列表
                        }else{
                            this.$message.error(response.data.message);
                        }
                    })
                })
            },

            //时间格式化
            formatTimeh(row, column){
                return this.moment(row.startTime).format("YYYY-MM-DD HH:mm:ss")
            },
            /* ****图片上传相关代码  如页面有图片上传功能放开注释 ****
            handleAvatarSuccess(res, file) {
                this.imageUrl = file.response;
            },
            beforeAvatarUpload(file) {
                const isJPG = file.type === 'image/jpeg';
                const isLt2M = file.size / 1024 / 1024 < 2;

                if (!isJPG) {
                    this.$message.error('上传头像图片只能是 JPG 格式!');
                }
                if (!isLt2M) {
                    this.$message.error('上传头像图片大小不能超过 2MB!');
                }
                return isJPG && isLt2M;
            }*/
        }
};
</script>
<style scoped>
.handle-box {
    margin-bottom: 20px;
}

.handle-select {
    width: 120px;
}

.handle-input {
    width: 300px;
    display: inline-block;
}

.table {
    width: 100%;
    font-size: 14px;
}

.red {
    color: #ff0000;
}

.mr10 {
    margin-right: 10px;
}

.table-td-thumb {
    display: block;
    margin: auto;
    width: 40px;
    height: 40px;
}

.avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
}

.avatar-uploader .el-upload:hover {
    border-color: #409EFF;
}

.el-upload--text {
    width: 100px;
    height: 100px;
}

.avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 100px;
    height: 100px;
    line-height: 100px;
    text-align: center;
}

.avatar {
    width: 100px;
    height: 100px;
    display: block;
}
</style>