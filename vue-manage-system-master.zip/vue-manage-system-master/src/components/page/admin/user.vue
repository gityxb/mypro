<template>
    <div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item>
                    <i class="el-icon-lx-cascades"></i> 用戶管理
                </el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="container">
            <div class="app-container">
                <div class="box">
                    <div class="filter-container">
                        <!--查询表单-->
                        <el-form :inline="true">
                            <el-form-item>
                                <el-button type="danger" class="butT" @click="batchDelete">批量删除</el-button>
                            </el-form-item>
                            
                            <el-form-item label="用户名">
                                <el-input v-model="searchMap.username" placeholder="用户名" class="filter-item"></el-input>
                            </el-form-item>
                            <!-- <el-form-item label="昵称">
                                <el-input v-model="searchMap.nickName" placeholder="昵称" class="filter-item"></el-input>
                            </el-form-item> -->
                            <el-form-item label="手机号码">
                                <el-input v-model="searchMap.phone" placeholder="手机号码" class="filter-item"></el-input>
                            </el-form-item>
                            
                            <el-button class="dalfBut" @click="fetchData()">查询</el-button>
                            <el-form-item>
                                <el-button type="primary" class="butT" @click="formVisible=true;pojo={}">新增</el-button>
                            </el-form-item>
                        </el-form>
                    </div>
                    <el-table 
                        :data="tableData"
                         border
                         @selection-change="handleSelectionChange"
                         >
                        <el-table-column
                          type="selection"
                          width="55"
                          >
                        </el-table-column>
                        <el-table-column prop="username" label="用户名" width="80"></el-table-column>
                        <el-table-column prop="nickName" label="昵称" width="80"></el-table-column>
                        <el-table-column label="头像" prop="" width="90">
                        <template slot-scope="scope"> <img style="width:70px;height:50px;" :src="scope.row.headPic" alt=""> </template>
                        </el-table-column>
                        <el-table-column prop="sex" label="性别" width="50" :formatter="formatterSex">
                        </el-table-column>
                        <el-table-column prop="phone" label="手机号码" width="120"></el-table-column>
                        <!--                    <el-table-column value-format="yyyy-MM-dd" prop="createdTime" label="创建时间" width="80"></el-table-column>-->
                        <!--                    <el-table-column prop="userLevel" label="用户等级" width="80"></el-table-column>-->
                        <!--                    <el-table-column prop="points" label="积分" width="80"></el-table-column>-->
                        <el-table-column prop="email" label="邮箱" width="200"></el-table-column>
                        <el-table-column prop="status" label="使用状态" width="80" :formatter="formatterStatus"></el-table-column>
                        <el-table-column prop="isMobileCheck" label="手机验证" width="80" :formatter="formatterPhone"></el-table-column>
                        <el-table-column prop="roleId" label="用户角色" width="80" :formatter="formatterRole"></el-table-column>
                        <el-table-column label="操作">
                            <template slot-scope="scope">
                                <el-button type="text" icon="el-icon-edit" @click="edit(scope.row.userId,scope.row.userId)">编辑</el-button>
                                <el-button type="text" icon="el-icon-delete" class="red" @click="dele(scope.row.userId,scope.row.username)">删除</el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                    <div class="pagination-container">
                        <el-pagination class="pagiantion" @size-change="fetchData" @current-change="fetchData" :current-page.sync="currentPage" :page-sizes="[10, 20, 30, 40]" :page-size="size" layout="total, sizes, prev, pager, next, jumper" :total="total">
                        </el-pagination>
                    </div>
                    <div class="add-form">
                        <!--弹出窗口-->
                        <el-dialog title="添加/编辑" :visible.sync="formVisible">
                            <el-form :model="pojo" :rules="rules" ref="pojo" label-width="80px">
                                <el-form-item label="用户名" prop="username">
                                    <el-input size="small" label-width="50" v-model="pojo.username"></el-input>
                                </el-form-item>
                                <el-form-item label="头像上传">
                                    <!--            <el-input v-model="pojo.headPic"></el-input>-->
                                    <el-upload style="width:100px;height:100px" class="avatar-uploader" 
                                    action="http://localhost:9102/upload/oss?floder=headPic" 
                                    :show-file-list="false" 
                                    :on-success="handleAvatarSuccess" 
                                    :before-upload="beforeAvatarUpload"
                                    :headers="myHeaders"
                                    >
                                        <img v-if="imageUrl" :src="imageUrl" class="avatar">
                                        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                                    </el-upload>
                                </el-form-item>
                                <el-form-item label="昵称" prop="nickName"> 
                                    <el-input size="small" v-model="pojo.nickName"></el-input>
                                </el-form-item>
                                <el-form-item label="性别" prop="sex">
                                    <!--            <el-input v-model="pojo.sex"></el-input>-->
                                    <el-radio-group v-model="pojo.sex" size="medium">
                                        <el-radio border label="1">男</el-radio>
                                        <el-radio border label="0">女</el-radio>
                                    </el-radio-group>
                                </el-form-item>
                                <el-form-item label="手机号码" prop="phone">
                                    <el-input size="small" v-model="pojo.phone"></el-input>
                                </el-form-item>
                                <!-- <el-form-item label="创建时间" prop="createdTime">
                                    <div class="block">
                                        <el-date-picker v-model="pojo.createdTime" type="date" placeholder="选择日期" format="yyyy-MM-dd">
                                        </el-date-picker>
                                    </div>
                                </el-form-item> -->
                                <!--                            <el-form-item label="用户等级"><el-input size="small" v-model="pojo.userLevel"></el-input></el-form-item>-->
                                <!--                            <el-form-item label="积分"><el-input size="small" v-model="pojo.points"></el-input></el-form-item>-->
                                <el-form-item label="密码" prop="password">
                                    <el-input size="small" type="password" v-model="pojo.password"></el-input>
                                </el-form-item>
                                <el-form-item label="邮箱" prop="email">
                                    <el-input size="small" v-model="pojo.email"></el-input>
                                </el-form-item>
                                <el-form-item label="使用状态" prop="status">
                                    <el-radio-group v-model="pojo.status" size="medium">
                                        <el-radio border label="1">正常</el-radio>
                                        <el-radio border label="0">禁用</el-radio>
                                    </el-radio-group>
                                </el-form-item>
                                <el-form-item label="手机验证" prop="isMobileCheck">
                                    <el-radio-group v-model="pojo.isMobileCheck" size="medium">
                                        <el-radio border label="1">支持</el-radio>
                                        <el-radio border label="0">禁用</el-radio>
                                    </el-radio-group>
                                </el-form-item>
                                <el-form-item label="用户角色" prop="roleId">
                                    <el-select v-model="pojo.roleId" placeholder="请选择">
                                        <el-option v-for="item in roleOptions" :key="item.power" :label="item.rname" :value="item.power">
                                        </el-option>
                                    </el-select>
                                </el-form-item>
                                <div style="clear:both"></div>
                            </el-form>
                            <span slot="footer" class="dialog-footer">
                                <el-button type="primary" @click="save('pojo')">保 存</el-button>
                                <el-button @click="formVisible = false">关 闭</el-button>
                            </span>
                        </el-dialog>
                    </div>
                </div>
            </div>
           
        </div>
    </div>
</template>
<script>
let token =  localStorage.getItem('token') 
export default {
    name: 'basetable',
    data() {
        var checkPhone = (rule, value, callback) => {
        if (!value) {
          return callback(new Error('手机号不能为空'));
        } else {
          const reg = /^1[3|4|5|7|8][0-9]\d{8}$/
          console.log(reg.test(value));
          if (reg.test(value)) {
            callback();
          } else {
            return callback(new Error('请输入正确的手机号'));
          }
        }
      };
        return {
            roleOptions: [],
            tableData: [],
            currentPage: 1,
            total: 10,
            size: 10,
            searchMap: {},
            pojo: {},
            formVisible: false,
            imageUrl: '',
            myHeaders: {Authorization: token},
            multipleSelection: [], //批量
            rules:{
                username: [
                    { required: true, message: '填写用户名', trigger: 'blur' }
                ],
                phone: [
                        { required: true, message: '请输入手机', trigger: 'blur' },
                        {validator: checkPhone, trigger: 'blur'}
                ],
                email: [
                        { required: true, message: '请输入邮件', trigger: 'blur' },
                        { type: 'email', message: '请输入正确的邮箱地址', trigger: 'blur' }
                ],
                nickName: [
                    { required: true, message: '请填写昵称', trigger: 'blur' }
                ],
                sex:[
                    { required: true, message: '请选择性别', trigger: 'change' }
                ],
                password: [
                    { required: true, message: '密码不能为空', trigger: 'blur' }
                ],
                status:[
                    { required: true, message: '使用状态不能为空', trigger: 'blur' }
                ],
                isMobileCheck:[
                    { required: true, message: '使用状态不能为空', trigger: 'blur' }
                ],
                roleId:[
                    { required: true, message: '请选择用户角色', trigger: 'blur' }
                ],

            }
        };
    },
    created() {
        this.fetchData();
    },
    methods: {
        fetchData() {
            this.axios.post(`/user/findPage?page=${this.currentPage}&size=${this.size}`, this.searchMap).then(response => {
                this.tableData = response.data.rows;
                this.total = response.data.total;
                console.log(response) 
            });
            this.axios.get(`/role/findAll`).then(response => {
                this.roleOptions = response.data;
                console.log(response);

            });

        },
        save(form) {

            this.$refs[form].validate((valid) => {
              if (valid) {
                this.pojo.imageUrl = this.imageUrl; //如页面有图片上传功能放开注释
                this.axios.post(`/user/${this.pojo.userId==null?'add':'update'}`, this.pojo).then(response => {
                    if (response.data.code == 0) {
                        this.$message.success('成功保存');
                        this.fetchData(); //刷新列表
                        this.formVisible = false; //关闭窗口
                        this.imageUrl=""
                    }
                    

                    console.log(response)
                });
              } else {
                return false;
              }
            });

            
        },
        edit(userId) {
            this.formVisible = true // 打开窗口
            // 调用查询
            this.axios.get(`/user/findById?userId=${userId}`).then(response => {
                this.pojo = response.data;
                this.imageUrl = this.pojo.headPic //显示图片  如页面有图片上传功能放开注释
            })
        },
        dele(userId,username) {
            this.$confirm('确定要删除此记录吗?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                this.axios.get(`/user/delete?userId=${userId}&username=${username}`).then(response => {
                    this.fetchData(); //刷新列表
                })
            })
        },
        //****图片上传相关代码  如页面有图片上传功能放开注释 ****
        handleAvatarSuccess(res, file) {
            this.$message.success('上传成功');
            console.log(file)
            this.imageUrl = file.response;
            this.pojo.headPic = file.response
            console.log(file.response)
        },
        beforeAvatarUpload(file) {
            // const isJPG = file.type === 'image/jpg';
            // const isLt2M = file.size / 1024 / 1024 < 2;
            //
            // if (!isJPG) {
            //     this.$message.error('上传头像图片只能是 JPG 格式!');
            // }
            // if (!isLt2M) {
            //     this.$message.error('上传头像图片大小不能超过 2MB!');
            // }
            // return isJPG && isLt2M;
        },
        batchDelete(){
            // console.log(this.multipleSelection.length)
            if(this.multipleSelection.length>0){
                this.axios.post(`/user/batchDelete`,this.multipleSelection).then(response=>{
                    if(response.data.code==0){
                        this.$message.success('删除成功');
                         this.fetchData();
                    }
                    console.log(response);
                })
            }
            
            // console.log(this.multipleSelection)
        },
        handleSelectionChange(val){
            let usernames=new Array()
            for (var i = 0; i < val.length; i++) {
                // console.log(val[i].username)
                usernames.push(val[i].username)
                
            }

            this.multipleSelection = usernames;
            
        },

        formatterSex(row, column) {
            return row.sex == "1" ? "男" : "女";
        },
        formatterDate(row, column) {
            let date = new Date();
            date.f
            return row.sex == "1" ? "男" : "女";
        },
        formatterPhone(row, column) {
            return row.isMobileCheck == "1" ? "支持" : "禁用";
        },
        formatterRole(row, column) {
            return row.roleId == "1" ? "管理员" : "普通用户";
        },
        formatterStatus(row, column) {
            return row.status == "1" ? "正常" : "禁用";
        }

    }
};
</script>
<style scoped>
.el-form-item{
    float: left;
}
.handle-box {
    margin-bottom: 20px;
}

.handle-select {
    width: 120px;
}

.handle-input {
    width: 300px;
    display: inline-block;
}

.table {
    width: 100%;
    font-size: 14px;
}

.red {
    color: #ff0000;
}

.mr10 {
    margin-right: 10px;
}

.table-td-thumb {
    display: block;
    margin: auto;
    width: 40px;
    height: 40px;
}

.avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
}

.avatar-uploader .el-upload:hover {
    border-color: #409EFF;
}

.el-upload--text {
    width: 100px;
    height: 100px;
}

.avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 100px;
    height: 100px;
    line-height: 100px;
    text-align: center;
}

.avatar {
    width: 100px;
    height: 100px;
    display: block;
}
</style>