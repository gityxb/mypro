<template>
    <div>
        <el-row>
            <el-col :span="24">
                <div style="background: black;height:36px;line-height: 36px;" class="grid-content bg-purple-dark">

                    <span v-show="flag" style="float: right;color: white;padding-right:20px;">欢迎 &nbsp;
                        <router-link style="background: white;padding: 5px;border-radius: 5px;font-size:14px;" :to="{ path: '/PersonCenter' }">{{username}}
                        </router-link>
                       &nbsp;
                       <router-link style="background: white;padding: 5px;border-radius: 5px;font-size:14px;" :to="{ path: '/login' }">退出
                        </router-link>
                    </span>
                    <span v-show="!flag" style="float: right;color: white;padding-right:20px;">
                        <router-link style="background: white;padding: 5px;border-radius: 5px;font-size:14px;" :to="{ path: '/login' }">登录
                        </router-link>&nbsp;
                        <router-link style="background: white;padding: 5px;border-radius: 5px;font-size:14px;" :to="{ path: '/register' }">注册
                        </router-link>
                    </span>
                    <div style="clear:both"></div>
                </div>
            </el-col>
        </el-row>
        <el-row>
            <el-col :span="24">
                <div style="background: white" class="grid-content bg-purple-light">
                    <el-menu :default-active="activeIndex" class="el-menu-demo" mode="horizontal" @select="">
                        <el-menu-item index="1"><router-link :to="{ path: '/index' }">首页</router-link></el-menu-item>
                        <el-menu-item index="2"><router-link :to="{ path: '/center' }">活动中心</router-link></el-menu-item>
                        <el-menu-item index="3"><router-link :to="{ path: '/PersonCenter' }">个人空间</router-link></el-menu-item>
                        <el-menu-item index="4"><router-link :to="{ path: '/ActivityMessage' }">留言反馈</router-link></el-menu-item>
                    </el-menu>
                </div>
            </el-col>
        </el-row>
        <router-view></router-view>
    </div>
</template>
<script>
export default {
    data() {
        return {
            activeIndex: '1',
            activeIndex2: '1',
            username:"",
            flag:false,
        };
        
    },
    methods:{
            getusername(){
                this.username =  localStorage.getItem('username');
                if(this.username){
                    this.flag=true
                }
            }
    },
    created() {
        this.getusername();
    },
}
</script>
<style type="text/css" scoped>
    ul.el-menu-demo a{
            display: inline-block;
            width: 100%;
    }
</style>