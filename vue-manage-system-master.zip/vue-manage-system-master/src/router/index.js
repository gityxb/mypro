import Vue from 'vue';
import Router from 'vue-router';

Vue.use(Router);

export default new Router({
    routes: [
        {
            path: '/admin',
            redirect: '/dashboard'
        },
        {
            path: '/',
            redirect: '/home'
        },

        {
            path: '/home',
            redirect: '/index'
        },

        {
            path: '/home',
            component:()=>import('../components/common/Home.vue'),
            meta:{title:'前台首页'},
            children:[
                {
                    path:'/index',
                    component:()=>import('../components/page/home/activityIndex.vue'),
                    meta:{title:'首页'}
                },
                {
                    path:'/center',
                    component:()=>import('../components/page/home/activityCenter.vue'),
                    meta:{title:'活动中心'}
                },
                {
                    path:'/center/detail',
                    component:()=>import('../components/page/home/activityCenterDetail.vue'),
                    meta:{title:'活动详情'}
                },
                {
                    path:'/comment',
                    component:()=>import('../components/page/home/activityComment.vue'),
                    meta:{title:'评论'}
                },
                {
                    path:'/Enroll',
                    component:()=>import('../components/page/home/activityEnroll.vue'),
                    meta:{title:'已报名'},
                    name:'Enroll'
                },
                {
                    path:'/Public',
                    component:()=>import('../components/page/home/activityPublic.vue'),
                    meta:{title:'已报名'},
                    name:'Public'
                },
                {
                    path:'/Publiced',
                    component:()=>import('../components/page/home/activityPuliced.vue'),
                    meta:{title:'已发布'},
                    name:'Publiced'
                },
                {
                    path:'/ActivityManager',
                    component:()=>import('../components/page/home/activityManager.vue'),
                    meta:{title:'活动管理'},
                    name:'ActivityManager'
                },
                {
                    path:'/PersonCenter',
                    component:()=>import('../components/page/home/personCenter.vue'),
                    meta:{title:'个人中心'},
                    name:'PersonCenter'
                },
                {
                    path:'/ActivityMessage',
                    component:()=>import('../components/page/home/message.vue'),
                    meta:{title:'留言中心'},
                    name:'Message'
                }
            ]
        },
        {
            path: '/admin',
            component: () => import(/* webpackChunkName: "home" */ '../components/common/Admin.vue'),
            meta: { title: '自述文件' ,permission: true},
            children: [
                {
                    path: '/dashboard',
                    component: () => import(/* webpackChunkName: "dashboard" */ '../components/page/Dashboard.vue'),
                    meta: { title: '系统首页',permission: true}
                },
                {
                    path: '/icon',
                    component: () => import(/* webpackChunkName: "icon" */ '../components/page/Icon.vue'),
                    meta: { title: '自定义图标' ,permission: true}
                },
                {
                    path: '/table',
                    component: () => import(/* webpackChunkName: "table" */ '../components/page/admin/user.vue'),
                    meta: { title: '用户管理' ,permission: true}
                },
                {
                    path: '/role',
                    component: () => import(/* webpackChunkName: "table" */ '../components/page/admin/role.vue'),
                    meta: { title: '角色管理' ,permission: true}
                },
                {
                    path: '/message',
                    component: () => import(/* webpackChunkName: "table" */ '../components/page/admin/message.vue'),
                    meta: { title: '留言管理' ,permission: true}
                },
                {
                    path: '/actCategory',
                    component: () => import(/* webpackChunkName: "table" */ '../components/page/admin/actCategory.vue'),
                    meta: { title: '分类管理' ,permission: true}
                },
                {
                    path: '/activity',
                    component: () => import(/* webpackChunkName: "table" */ '../components/page/admin/activity.vue'),
                    meta: { title: '活动管理' ,permission: true}
                },
                {
                    path: '/tabs',
                    component: () => import(/* webpackChunkName: "tabs" */ '../components/page/Tabs.vue'),
                    meta: { title: 'tab选项卡' }
                },
                {
                    path: '/form',
                    component: () => import(/* webpackChunkName: "form" */ '../components/page/BaseForm.vue'),
                    meta: { title: '基本表单' }
                },
                {
                    // 富文本编辑器组件
                    path: '/editor',
                    component: () => import(/* webpackChunkName: "editor" */ '../components/page/VueEditor.vue'),
                    meta: { title: '富文本编辑器' }
                },
                {
                    // markdown组件
                    path: '/markdown',
                    component: () => import(/* webpackChunkName: "markdown" */ '../components/page/Markdown.vue'),
                    meta: { title: 'markdown编辑器' }
                },
                {
                    // 图片上传组件
                    path: '/upload',
                    component: () => import(/* webpackChunkName: "upload" */ '../components/page/Upload.vue'),
                    meta: { title: '文件上传' }
                },
                {
                    // vue-schart组件
                    path: '/charts',
                    component: () => import(/* webpackChunkName: "chart" */ '../components/page/BaseCharts.vue'),
                    meta: { title: 'schart图表' }
                },
                {
                    // 拖拽列表组件
                    path: '/drag',
                    component: () => import(/* webpackChunkName: "drag" */ '../components/page/DragList.vue'),
                    meta: { title: '拖拽列表' }
                },
                {
                    // 拖拽Dialog组件
                    path: '/dialog',
                    component: () => import(/* webpackChunkName: "dragdialog" */ '../components/page/DragDialog.vue'),
                    meta: { title: '拖拽弹框' }
                },
                {
                    // 国际化组件
                    path: '/i18n',
                    component: () => import(/* webpackChunkName: "i18n" */ '../components/page/I18n.vue'),
                    meta: { title: '国际化' }
                },
                {
                    // 权限页面
                    path: '/permission',
                    component: () => import(/* webpackChunkName: "permission" */ '../components/page/Permission.vue'),
                    meta: { title: '权限测试', permission: true }
                },
                {
                    path: '/404',
                    component: () => import(/* webpackChunkName: "404" */ '../components/page/404.vue'),
                    meta: { title: '404' }
                },
                {
                    path: '/403',
                    component: () => import(/* webpackChunkName: "403" */ '../components/page/403.vue'),
                    meta: { title: '403' }
                },
                {
                    path: '/donate',
                    component: () => import(/* webpackChunkName: "donate" */ '../components/page/Donate.vue'),
                    meta: { title: '支持作者' }
                }
            ]
        },
        {
            path: '/login',
            component: () => import(/* webpackChunkName: "login" */ '../components/page/Login.vue'),
            meta: { title: '登录' }
        },
        {
            path: '/register',
            component: () => import(/* webpackChunkName: "login" */ '../components/page/register.vue'),
            meta: { title: '注册' }
        },
        {
            path: '*',
            redirect: '/404'
        }
    ]
});
