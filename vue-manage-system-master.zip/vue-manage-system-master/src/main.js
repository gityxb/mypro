import Axios from 'axios';
import Vue from 'vue';
import App from './App.vue';
import router from './router';
import ElementUI from 'element-ui';
import VueI18n from 'vue-i18n';
import { messages } from './components/common/i18n';
import 'element-ui/lib/theme-chalk/index.css'; // 默认主题
// import './assets/css/theme-green/index.css'; // 浅绿色主题
import './assets/css/icon.css';
import './components/common/directives';
import 'babel-polyfill';
import Moment from 'moment'



Axios.defaults.baseURL = 'http://localhost:9102/'

Vue.config.productionTip = false;
Vue.use(VueI18n);
Vue.use(ElementUI, {
    size: 'small'
});
Vue.prototype.axios = Axios;
const i18n = new VueI18n({
    locale: 'zh',
    messages
});

Vue.prototype.moment=Moment;

Vue.filter('formatTime', function (val) {
  return Moment(val).format("YYYY-MM-DD");
});
Vue.filter('formatTimeh', function (val) {
  return Moment(val).format("YYYY-MM-DD HH:mm:ss");
});
Vue.filter('formatSex', function (val) {

  return val=="0"?"女":"男";
});

//axios拦截器

Axios.interceptors.request.use(function (config) {
    // 在发送请求之前做些什么，例如加入token
    if (localStorage.getItem('token')){
        console.log(localStorage.getItem('token'))
    config.headers['Authorization'] = localStorage.getItem('token')
        
    }
    return config;
  }, function (error) {
    // 对请求错误做些什么
    return Promise.reject(error);
  });

Axios.interceptors.response.use(
  response => {
    //当返回信息为未登录或者登录失效的时候重定向为登录页面
    if (response.data.code == 401) {
        alert("请登录")
        // this.$router.push({path:'login'});
      router.push({
        path: "/login",
        querry: { redirect: router.currentRoute.fullPath }//从哪个页面跳转
      })
    }else if(response.data.code == 402){
        alert("token过期请重新登录")
        router.push({
        path: "/login",
        querry: { redirect: router.currentRoute.fullPath }//从哪个页面跳转
      })

    }else if(response.data.code==1){
        // alert(response.data.message)

    }
    return response;
  },
  error => {
    return Promise.reject(error)
  }
)
// Axios.interceptors.response.use(

//     response => {
//         // 如果返回的状态码为200，说明接口请求成功，可以正常拿到数据
//         // 否则的话抛出错误
        
//         console.log('ff')
//        console.log(response)
        // if(response.status === 200){
        //     if (response.data.code === 0) {
              
        //         console.log("这是零啊,成功了呀")
        //         return Promise.resolve(response);
        //     } else if(response.data.code === 401||response.data.code === 402||response.data.code === 1){
        //         console.log("错误的呀")
        //         router.replace({
        //                 path: '/login',
                        
        //             });
        //         return Promise.reject(response);
        //     }
        // }
        
    // },
    // error => {
    //     console.log("hahah")
    //     // if (error.response.data.code) {
    //     //     switch (error.response.data.code) {
    //     //         // 401: 未登录
    //     //         // 未登录则跳转登录页面，并携带当前页面的路径
    //     //         // 在登录成功后返回当前页面，这一步需要在登录页操作。
    //     //         case 401:
    //     //             // router.replace({
    //     //             //     path: '/login',
    //     //             //     query: {
    //     //             //         redirect: router.currentRoute.fullPath
    //     //             //     }
    //     //             // });
    //     //             console.log("这是401呀")
    //     //             break;

    //     //         // 403 token过期
    //     //         // 登录过期对用户进行提示
    //     //         // 清除本地token和清空vuex中token对象
    //     //         // 跳转登录页面
    //     //         case 402:
    //     //             //   Toast({
    //     //             //     message: '登录过期，请重新登录',
    //     //             //     duration: 1000,
    //     //             //     forbidClick: true
    //     //             // });
    //     //             // 清除token
    //     //             // localStorage.removeItem('token');
    //     //             // store.commit('loginSuccess', null);
    //     //             // // 跳转登录页面，并将要浏览的页面fullPath传过去，登录成功后跳转需要访问的页面
    //     //             // setTimeout(() => {
    //     //             //     router.replace({
    //     //             //         path: '/login',
    //     //             //         query: {
    //     //             //             redirect: router.currentRoute.fullPath
    //     //             //         }
    //     //             //     });
    //     //             // }, 1000);
    //     //             console.log("这是402呀")
                  
    //     //             break;

    //     //         // 404请求不存在
    //     //         case 1:
    //     //             // Toast({
    //     //             //     message: '网络请求不存在',
    //     //             //     duration: 1500,
    //     //             //     forbidClick: true
    //     //             // });
    //     //             console.log("这是1呀")
                
    //     //             break;
    //     //         // 其他错误，直接抛出错误提示
    //     //         default:
    //     //             Toast({
    //     //                 message: error.response.data.code,
    //     //                 duration: 1500,
    //     //                 forbidClick: true
    //     //             });
    //     //     }
    //     //     return Promise.reject(error.response);
    //     // }
        
    // }

// )

//使用钩子函数对路由进行权限跳转 && to.path !== '/login'
router.beforeEach((to, from, next) => {
    document.title = `${to.meta.title} | vue-manage-system`;
    const power = localStorage.getItem('power');
    if (power!="3"&&to.meta.permission) {
        console.log("home")
        next("/home");
    } else if (power==="3"&&to.meta.permission){
        console.log("admin")
        // 如果是管理员权限则可进入，这里只是简单的模拟管理员权限而已
        // console.log(typeof(role));
        // console.log(role === 3);
        // if(power === "3"){
        //     next("/admin");
        // }else if(power === "1"||power === "2"){
        //     next("/home")
        // }else
        next()
        // power === "3" ? next() : next('/login');

    } else {
        // 简单的判断IE10及以下不进入富文本编辑器，该组件不兼容
        if (navigator.userAgent.indexOf('MSIE') > -1 && to.path === '/editor') {
            Vue.prototype.$alert('vue-quill-editor组件不兼容IE10及以下浏览器，请使用更高版本的浏览器查看', '浏览器不兼容通知', {
                confirmButtonText: '确定'
            });
        } else {
           
            console.log(to.meta)
            next();
            
        }

    }
});

new Vue({
    router,
    i18n,
    render: h => h(App)
}).$mount('#app');
